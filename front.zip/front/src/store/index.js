import { createStore } from 'vuex'

export default createStore({
  state: {
    //定义全局变量模块，存储与使用格式如下
    //this.$store.getters.userid
    //this.$store.commit('setgender',res.data.gender);
    id:"",
    dept:"",
    account:"",
    name:"",
    password:"",
    head_img:"",
    gender:1,
    user_state:1,
    mobile:"",
    email:"",
    birthday:"",
    roleId:'',
    admin:''
  },
  getters: {
    id: state => state.id,
    dept: state => state.dept,
    account: state => state.account,
    name: state => state.name,
    password: state => state.password,
    head_img: state => state.head_img,
    gender: state => state.gender,
    user_state: state => state.user_state,
    mobile: state => state.mobile,
    email: state => state.email,
    birthday: state => state.birthday,
    admin: state => state.admin,
    roleId: state => state.roleId,
  },
  mutations: {
    setId:(state,id)=>{state.id=id;},
    setDept:(state,dept)=>{state.dept=dept;},
    setAccount:(state,account)=>{state.account=account;},
    setName:(state,name)=>{state.name=name;},
    setPassword:(state,password)=>{state.password=password;},
    setHead_img:(state,head_img)=>{state.head_img=head_img;},
    setGender:(state,gender)=>{state.gender=gender;},
    setState:(state,user_state)=>{state.state=user_state;},
    setMobile:(state,mobile)=>{state.mobile=mobile;},
    setBirthday:(state,birthday)=>{state.birthday=birthday;},
    setRoleId: (state,roleId)=>{state.roleId=roleId;},
    setAdmin: (state,admin)=>{state.admin=admin;}
  },
  actions: {
  },
  modules: {
  }
})
