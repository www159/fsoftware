<template>
  <div>
    <el-card>
      <el-row :gutter="20">
        <el-col :span="8">
          <!-- 搜索与添加区域 -->
          <el-input placeholder="请输入内容" v-model.trim.lazy="searchText" @keyup.enter="searchTableData">
            <template #append>
              <el-button class="el-icon-search" @click="searchTableData"></el-button>
            </template>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-button type="primary" @click="openAddRoleDialog">添加角色</el-button>
        </el-col>
        <el-col :span="4">
          <el-button type="danger" @click="multipleDelete">批量删除</el-button>
        </el-col>
<!--        <el-col :span="4">-->
<!--          <el-button type="info" @click="selectAllRows">全选</el-button>-->
<!--        </el-col>-->
      </el-row>
    </el-card>
    <el-scrollbar>
      <el-table :data="paginatedTableData" ref="multipleTableRef" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="roleName" label="角色名称" span="4"></el-table-column>
<!--        <el-table-column prop="state" label="权限" span="4"></el-table-column>-->
<!--        <el-table-column label="权限名" span="4">-->
<!--          <template #default="scope">-->
<!--            <span v-if="scope.row.state === 1">个人空间</span>-->
<!--            <span v-else-if="scope.row.state === 2">纳税服务</span>-->
<!--            <span v-else-if="scope.row.state === 3">权限3</span>-->
<!--            <span v-else-if="scope.row.state === 4">权限4</span>-->
<!--          </template>-->
<!--        </el-table-column>-->
        <!--        <el-table-column prop="status" label="状态"></el-table-column>-->
        <el-table-column label="操作">
          <template v-slot="scope">
            <el-button type="primary" @click="editRole(scope.row)">编辑</el-button>
            <el-button type="danger" @click="deleteRole(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-scrollbar>

    <!-- 添加/编辑角色弹窗 -->
    <el-dialog v-model="showAddRoleDialog" title="添加/编辑用户" @close="resetEditingRole">
      <el-form :model="editingRole" label-width="100px" :rules="formRules">
        <el-form-item label="角色名称">
          <el-input v-model="editingRole.roleName" :disabled="editingRole.editing"></el-input>
        </el-form-item>
        <el-form-item label="权限">
          <template v-if="editingRole.operation === 'addRoleOperation'">
            <el-radio-group v-model="editingRole.authority">
              <el-radio :label="1">个人空间</el-radio>
              <el-radio :label="2">纳税服务</el-radio>
<!--              <el-radio :label="3">权限3</el-radio>-->
<!--              <el-radio :label="4">权限4</el-radio>-->
            </el-radio-group>
          </template>
          <template v-else-if="editingRole.operation === 'editRoleOperation'">
            <el-radio-group v-model="editingRole.authority">
              <el-radio :label="1">权限1</el-radio>
              <el-radio :label="2">权限2</el-radio>
              <el-radio :label="3">权限3</el-radio>
              <el-radio :label="4">权限4</el-radio>
            </el-radio-group>
          </template>
        </el-form-item>
        <!--        <el-form-item label="状态">-->
        <!--          <el-input v-model="editingRole.status"></el-input>-->
        <!--        </el-form-item>-->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="cancelAddRole">取消</el-button>
        <el-button type="primary" @click="saveRole">保存</el-button>
      </div>
    </el-dialog>

    <!--分页-->
    <el-pagination
        @size-change="handlePageSizeChange"
        @current-change="handleCurrentPageChange"
        :current-page="currentPage"
        :page-sizes="[10, 20, 30, 50]"
        :page-size="pageSize"
        :total="filteredTableData.length"
        layout="sizes, prev, pager, next, jumper"
        class="pagination-centered"
    >
    </el-pagination>
  </div>
</template>

<script>
import {ref, computed, watch, onMounted} from 'vue';
import axios from 'axios';
import ServicePort from './ServicePort';
import {
  ElTable,
  ElDialog,
  ElMessageBox,
  ElForm,
  ElFormItem,
  ElInput,
  ElButton,
  ElMessage,
  ElPagination
} from 'element-plus';

export default {
  components: {ElTable, ElDialog, ElMessageBox, ElForm, ElFormItem, ElInput, ElButton, ElMessage, ElPagination},
  setup() {
    const port = 80;
    const searchText = ref('');
    const tableData = ref([]);
    //搜索数据
    const filteredTableData = ref([]);
    //tableData副本
    const allTableData = ref([]);
    const showAddRoleDialog = ref(false);
    const editingRole = ref({});
    const multipleTableRef = ref();
    const multipleSelection = ref([]);
    // 分页
    const currentPage = ref(1);
    const pageSize = ref(5);
    const totalPages = ref(0);
    const formRules = {
      roleName: [
        { required: true, message: '角色名称不能为空', trigger: 'blur' },
      ],
    };
    // const filteredTableData = computed(() => {
    //   if (searchText.value) {
    //     const keyword = searchText.value.trim().toLowerCase();
    //     return tableData.value.filter((item) => item.roleName.toLowerCase().includes(keyword));
    //   } else {
    //     return tableData.value;
    //   }
    // });
    // const isDataLoaded = ref(false);
    //获取数据
    const fetchTableData = async () => {
      try {
        const data = await ServicePort.fetchTableData();
        //test
        // // console.log("tableData:",data);
        // isDataLoaded.value = true;
        tableData.value = data;
        allTableData.value = [...data];
        filteredTableData.value = tableData;
        //test
        // console.log("filteredTableData:",filteredTableData);
        // console.log("tableData:",tableData);
      } catch (error) {

      }
    };

    onMounted(() => {
      fetchTableData();
    });

    const searchTableData = () => {
      // 清除当前页和选择的数据
      currentPage.value = 1;
      multipleSelection.value = [];

      if (searchText.value) {
        const keyword = searchText.value.trim().toLowerCase();
        const filteredData = tableData.value.filter((item) => item.roleName.toLowerCase().includes(keyword));
        if (filteredData.length === 0) {
          ElMessageBox.alert('查询失败', '提示', {
            type: 'error',
          });
        } else {
          filteredTableData.value = filteredData;
          totalPages.value = Math.ceil(filteredData.length / pageSize.value);
        }
      } else {
        filteredTableData.value = tableData.value;
      }
    };

    // const multipleDelete = () => {
    //   if (multipleSelection.value.length > 0) {
    //     ElMessageBox.confirm('确定要删除选中的数据吗？', '提示', {
    //       type: 'warning',
    //     })
    //         .then(() => {
    //           const selectedRows = multipleSelection.value;
    //           tableData.value = tableData.value.filter((row) => !selectedRows.includes(row));
    //           multipleSelection.value = [];
    //           ElMessage.success('删除成功');
    //         })
    //         .catch(() => {
    //           // 取消删除
    //         });
    //   } else {
    //     ElMessage.warning('请先选择要删除的数据');
    //   }
    // };

    const multipleDelete = async () => {
      if (multipleSelection.value.length > 0) {
        try {
          const selectedRows = multipleSelection.value;
          const roleIds = selectedRows.map((row) => row.roleId); // 唯一的 id 字段
          console.log(roleIds);
          await axios.delete(`http://localhost:${port}/roles/batch`, { data: roleIds });
          tableData.value = tableData.value.filter((row) => !selectedRows.includes(row)); // 在前端中过滤掉选中的行数据
          multipleSelection.value = [];
          ElMessage.success("批量删除成功");
        } catch (error) {
          console.error("Error deleting roles:", error);
        }
      } else {
        ElMessage.warning("请先选择要删除的数据");
      }
    };

    // const selectAllRows = () => {
    //   if (isAllSelected) {
    //     // 已经全选，取消全选
    //     multipleSelection.value = [];
    //   } else {
    //     // 未全选，全选所有数据行
    //     console.log(filteredTableData)
    //     multipleSelection.value = [...filteredTableData.value];
    //   }
    // };
    //
    // const isAllSelected = computed(() => multipleSelection.value.length === filteredTableData.value.length);


    const editRole = (row) => {
      showAddRoleDialog.value = true;
      editingRole.value = {...row, editing: true, operation: 'editRoleOperation'};
    };

    // const deleteRole = (index) => {
    //   console.log(tableData.value[index])
    //   console.log(tableData.value[index].roleId)
    //   tableData.value.splice(index, 1);
    // };

    const deleteRole = async (row) => {
      const roleId = row.roleId; // 唯一的 id 字段
      console.log(roleId);
      console.log(row);
      try {
        await axios.delete(`http://localhost:${port}/roles/delete/${roleId}`);
        tableData.value = tableData.value.filter((item) => item.roleId !== roleId);; // 在前端中删除指定索引位置的数据
        filteredTableData.value = filteredTableData.value.filter((item) => item.roleId !== roleId); // 更新 filteredTableData
      } catch (error) {
        console.error("Error deleting role:", error);
      }
    };


    const openAddRoleDialog = () => {
      showAddRoleDialog.value = true;
      editingRole.value = {editing: false, operation: 'addRoleOperation'};
    };

    const cancelAddRole = () => {
      showAddRoleDialog.value = false;
      editingRole.value = {};
    };

    const saveRole = async () => {
      if (editingRole.value.roleName && editingRole.value.authority) {
        editingRole.value.state = Number(editingRole.value.authority);
        const existingRole = tableData.value.find((role) => role.roleName === editingRole.value.roleName && role.state === editingRole.value.state);
        if (existingRole) {
          ElMessage.warning('已经给该角色赋予过该权限了');
          return; // 如果存在相同的角色，停止保存操作
        }

        if (editingRole.value.editing) {
          //编辑
          // console.log(editingRole.value);
          // console.log(editingRole.value.roleId);
          const updateRole ={
            roleId:editingRole.value.roleId,
            roleName:editingRole.value.roleName,
            state:editingRole.value.state
          }
          // console.log(editingRole.value.roleId);
          // console.log(updateRole);
          const response = await axios.put(`http://localhost:${port}/roles/update/${editingRole.value.roleId}`, updateRole);
          // console.log(response); // 可选：打印响应结果
          const index = tableData.value.findIndex((role) => role.roleName === editingRole.value.roleName);
          if (index !== -1) {
            tableData.value[index] = {...editingRole.value, editing: false};
          }
        } else {
          //保存
          const addRole = {
            roleId: editingRole.value.roleId,
            roleName:editingRole.value.roleName,
            state:editingRole.value.state
          }
          const response = await  axios.post(`http://localhost:${port}/roles/addRole`,addRole)
          tableData.value.push({...editingRole.value});
        }
        showAddRoleDialog.value = false;
        editingRole.value = {};
      } else {
        ElMessage.warning('请填写必要信息');
      }
    };

    const resetEditingRole = () => {
      editingRole.value = {};
    };

    const handleSelectionChange = (val) => {
      multipleSelection.value = val;
    };

    const paginatedTableData = computed(() => {
      const startIndex = (currentPage.value - 1) * pageSize.value;
      const endIndex = startIndex + pageSize.value;
      totalPages.value = Math.ceil(filteredTableData.value.length / pageSize.value);
      return filteredTableData.value.slice(startIndex, endIndex);
    });

    const handlePageSizeChange = (newPageSize) => {
      pageSize.value = newPageSize;
      currentPage.value = 1;
    };

    const handleCurrentPageChange = (newPage) => {
      const totalPages = Math.ceil(filteredTableData.value.length / pageSize.value);
      currentPage.value = Math.max(1, Math.min(newPage, totalPages));
    };

    watch(tableData, (newTableData) => {
      filteredTableData.value = newTableData;
    });

    return {
      searchText,
      tableData,
      showAddRoleDialog,
      editingRole,
      multipleTableRef,
      multipleSelection,
      currentPage,
      pageSize,
      totalPages,
      filteredTableData,
      formRules,
      searchTableData,
      multipleDelete,
      // selectAllRows,
      editRole,
      deleteRole,
      openAddRoleDialog,
      cancelAddRole,
      saveRole,
      resetEditingRole,
      handleSelectionChange,
      paginatedTableData,
      handlePageSizeChange,
      handleCurrentPageChange,
    };


  },
};
</script>