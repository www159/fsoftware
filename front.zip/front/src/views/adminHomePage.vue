<template>
  <div class="common-layout">
    <el-container>
      <el-header class="top_nav">
        <div class="top_content">
          <el-text class="headerText">国税OA办公后台管理</el-text>
          <span class="top_line"></span>
          <!-- 顶部菜单栏-->
          <el-menu class="top_page_nav" mode="horizontal">
            <el-menu-item index="1">首页</el-menu-item>
            <el-menu-item index="2" disabled>Info</el-menu-item>
            <el-menu-item index="3">消息</el-menu-item>
          </el-menu>
          <!--用户中心 -->
          <div class="top_user_info">
            <el-avatar
                src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
            />
          </div>
        </div>
      </el-header>
      <el-container>
        <el-aside width="200px">
          <!--侧边导航栏-->
          <el-menu class="aside_nav"  :router="true">
            <div v-for="(item,index) in asideMenu" :key="index">
              <el-menu-item :index="item.router">
                <el-icon>
                  <component :is="item.icon"></component>
                </el-icon>
                <span>{{ item.title }}</span>
              </el-menu-item>
            </div>
          </el-menu>
        </el-aside>
        <!-- 主显示界面-->
        <el-main>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script setup>
import {Avatar, UserFilled} from '@element-plus/icons-vue'
import {reactive} from "vue";

const iconArray = [
  {
    id: '1',
    icon: Avatar,
    title: '角色管理',
    router: 'actorManagement',
    subClass: []
  },
  {
    id: '2',
    icon: UserFilled,
    title: '系统用户管理',
    router: 'systemUserManagement',
    subClass: []
  },
]
const asideMenu = reactive(iconArray)



</script>


<style scoped>
.aside_nav {
  background-color: var(--el-color-primary-light-7);
  color: var(--el-text-color-primary);
}

.top_page_nav {
  background-color: var(--el-color-primary-light-7);
  color: var(--el-text-color-primary);
  float: left;
  margin-left: 40px;
  width: 370px;
  height: 56px;
  line-height: 56px;
  position: relative;
}

.top_user_info {
  float: right;
  color: #fff;
  height: 40px;
  position: relative;
  margin-top: 8px;
  cursor: pointer;
}

.top_line {
  display: inline-block;
  width: 2px;
  height: 28px;
  margin-left: 15px;
  background: hsla(0, 0%, 100%, .6);
  margin-top: 14px;
  float: left;
}

.top_content {
  position: relative;
  width: 100%;
  height: 56px;
  border-bottom: 1px solid hsla(0, 0%, 100%, .6);
  background-size: 100% 100%;
}

.top_nav {
  width: 100%;
  height: 56px;
  position: relative;
}

.headerText {
  height: 40px;
  margin-top: 8px;
  float: left;
}

.common-layout {
  height: 100%;
}

.el-container {
  height: 100%;
}

.el-header {
  position: relative;
  background-color: var(--el-color-primary-light-7);
  color: var(--el-text-color-primary);
}

.el-aside {
  color: var(--el-text-color-primary);
  background: var(--el-color-primary-light-8);
}

.el-main {
  padding: 0;
}
</style>