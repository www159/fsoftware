<template>
  <div class="complaint-management">
    <!-- 标题栏 -->
    <div class="title-bar">
      <div class="title">投诉信息受理</div>
    </div>
    <!-- 搜索栏 -->
    <el-row class="search-row">
      <el-col :span="7">
        <el-input v-model="search.dept" placeholder="请输入被投诉部门"></el-input>
      </el-col>
      <el-col :span="7">
        <el-date-picker v-model="search.date" type="datetimerange" placeholder="选择日期"></el-date-picker>
      </el-col>

      <el-col :span="4" >
        <el-form-item>
          <el-select v-model.trim="search.state" clearable placeholder="状态" >
            <el-option
                v-for="item in AcceptedOrNot"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="1">
        <el-button type="primary" @click="searchComplaintments">搜索</el-button>
      </el-col>
    </el-row>

    <!-- 投诉信息展示表格 -->
    <el-table :data="complaints" style="width: 100%">
      <el-table-column label="投诉标题" prop="title"></el-table-column>
      <el-table-column label="被投诉部门" prop="toComplaintDept"></el-table-column>
      <el-table-column label="被投诉人" prop="toComplaintName"></el-table-column>
      <el-table-column label="投诉时间" prop="time"></el-table-column>
      <el-table-column label="状态" prop="state">
        <template #default="{ row }">
          {{ statusMappings[row.state] }}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template #default="{ row }">
          <el-button type="text" @click="viewComplaint(row)">{{ row.state === 0? '处理' : '' }}</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
  <el-dialog title="投诉处理" v-model="complaintDialogVisible">
    <div>
      <p style="font-size: 20px;"><strong>投诉标题：</strong>{{ selectedComplaint.title }}</p>
      <p style="font-size: 18px;"><strong>投诉内容：</strong>{{ selectedComplaint.content }}</p>

      <el-form ref="replyForm" :model="replyForm" label-width="80px">
        <el-form-item label="处理意见">
          <el-input type="textarea" v-model="replyForm.replyContent" rows="3"></el-input>
        </el-form-item>
        <el-form-item label="处理日期">
          <el-date-picker v-model="replyForm.time" type="date" placeholder="选择日期"></el-date-picker>
        </el-form-item>
      </el-form>
    </div>

    <div slot="footer" class="dialog-footer">
      <el-button @click="cancelComplaint">取消</el-button>
      <el-button type="primary" @click="completeComplaint">完成</el-button>
    </div>
  </el-dialog>
</template>

<script>
import axios from "axios";
import ServicePort from './ServicePort';
export default {
  name:'complaint',
  data() {
    return {
      statusMappings: {
        '0': '未受理',
        '1': '已受理',
        '2': '失效',
      },
      searchTitle: '',
      searchDate: '',
      search:{
        dept: '',
        date: '',
        state:'',
      },
      selectedComplaint: {
        title: '',
        content: '',
      },
      currentEditComplaint: null,
      replyForm: {
        replyContent: ''
      },
      complaintDialogVisible: false,
      complaints: [
      ],
      complaintForm: { // 投诉表单数据
        complaintNumber: '',
        complaintTitle: '',
        complaintContent: '',
        complaintDate:'',
        complaintState:'',
        // 其他表单字段根据需要添加
      },
      AcceptedOrNot:[
        {
          value: '1',
          label: '已受理',
        },
        {
          value: '0',
          label: '未受理',
        },
      ],
    };
  },
  mounted() {
    this.fetchComplaint();
  },
  methods: {
    async fetchComplaint() {
      try {
        const searchParams = {
          toComplaintDept: this.search.dept,
          startDate: this.search.date[0], // 开始日期
          endDate: this.search.date[1],   // 结束日期
          state: this.search.state,
        };
        const complaints = await ServicePort.fetchComplaint(searchParams);
        this.complaints = complaints;
      } catch (error) {
        // 处理错误
      }
    },
    searchComplaintments() {
      this.fetchComplaint();
    },
    viewComplaint(row) {
      this.currentEditComplaint = row;
      // 将公告信息填充到编辑表单中
      this.selectedComplaint.title = row.title;
      this.selectedComplaint.content = row.content;
      this.selectedComplaint.complaintId = row.complaintId
      // 打开编辑对话框
      this.complaintDialogVisible = true;
    },
    cancelComplaint() {
      this.replyForm.content = '';
      this.complaintDialogVisible = false;
    },
    async completeComplaint(){
      try {
        const complaintData = {
          content: this.replyForm.replyContent,
          complaintId:this.selectedComplaint.complaintId,
          replyerId:this.$store.getters.id,
          time:this.replyForm.time,
        };
        console.log(complaintData);

        await axios.post(`http://localhost:80/complaint/reply`, complaintData);

        // 清空编辑表单
        this.replyForm.replyContent = '';
        this.replyForm.time = '';
        alert('处理投诉成功');
        // 关闭编辑对话框
        this.complaintDialogVisible = false;
        // 重新获取公告列表
        this.fetchComplaint();
      } catch (error) {
        // 处理错误
      }
    },
  }
};
</script>

<style scoped>
.complaint-management {
  padding: 0;
}

.title {
  color: #000;
  font-size: 24px;
}

.search-row {
  margin-top: 10px;
  margin-bottom: 10px;
}
.title-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #f5f5f5;
}
</style>
