<template>
  <div class="base">
    <div class="loginArea">
      <div class="image-container">
        <img src="../assets/login.png" alt="login">
      </div>
      <div class="form-container">
        <div class="form-title">国税OA办公系统</div>
        <el-form  label-width="60px" label-position ="right">
          <el-form-item label="工号" style="margin-bottom: 35px;font-size: 20px;font-weight: bolder" prop="pass" >
            <el-input v-model="loginForm.account" type="account" />
          </el-form-item>
          <el-form-item label="密码" style="margin-bottom: 35px;font-size: 20px;font-weight: bolder" prop="checkPass">
            <el-input v-model="loginForm.password" type="password" prefix-icon="el-icon-lock" show-password/>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm">登录</el-button>
            <!--            登录结果反馈-->
            <div v-if="showError">登录信息有误请检查后重试</div>
          </el-form-item>
          <el-form-item>
            <el-button type="text" @click="forgetpassword">忘记密码</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "LoginView",
  data(){
    return{
      loginForm:{
        account: "",
        password: "",
      },
      showError: false,
      id: '',
      roleId:''
    }
  },
  methods:{
    submitForm(){
      axios.post('http://localhost:80/users/login',{account:this.loginForm.account,password:this.loginForm.password}).then(response=>{
        if(response.status===200){
          this.$store.commit('setAccount',this.loginForm.account);
          this.$store.commit('setName',response.data.name);
          this.$store.commit('setId',response.data.id);
          this.id=this.$store.getters.id;
          this.$store.commit('setDept',response.data.dept);
          this.$store.commit('setGender',response.data.gender);
          this.$store.commit('setHead_img',response.data.head_img);
          this.$store.commit('setState',response.data.state);
          this.$store.commit('setMobile',response.data.mobile);
          this.$store.commit('setBirthday',response.data.birthday);
          this.getRole(this.id);
          this.roleId=this.$store.getters.roleId;
          if(this.roleId===0){
            this.$router.replace({path:'/systemUserManagement'});
          }else if(this.roleId===1){
            this.$router.replace({path:'/myworkspace'});
          }else if(this.roleId===2){
            this.$router.replace({path:'/myworkspace'});
          }
        }else if(response.status===401){
          this.showError=true
        }
      }).catch(error=>console.error(error))
    },
    forgetpassword(){
      this.$alert('请联系管理员找回密码','提示',{
        confirmButtonText:'确定',
        type: 'warning'
      })
    },
    getRole(userId){
      axios.get(`http://localhost:80/users/getRoleId/${userId}`).then(response=>{
        this.$store.commit('setRoleId',response.data)
      })
    }
  }
}
</script>

<style scoped>

.base{
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-image: url("../assets/background.jpg");
  background-size: 100%;
}
.loginArea{
  width: 600px;
  height: 350px;
  background-color: #fff;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
}
.image-container {
  width: 294px;
  height: 350px;
  display: flex;
  align-items: flex-start;
}
.image-container image{
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.form-container {
  width: 290px;
  height: 100%;
  right: 0;
  position: fixed;
  top: 0;
  padding: 15px;
}
.form-title {
  font-size: 1.75rem;
  line-height: 5.45rem;
  font-weight: 600;
  text-align: center;
  color: #2366C4;
}


</style>
