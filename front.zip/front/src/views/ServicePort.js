import axios from 'axios';

class ServicePort {
    static port = 80; // 默认端口号为80

    //用户管理
    static fetchTableData = async () => {
        try {
            const response = await axios.get(`http://localhost:${ServicePort.port}/roles/getAll`);
            console.log(response);
            return response.data;
        } catch (error) {
            console.error('Error fetching table data:', error);
            throw error;
        }
    };

    //系统用户管理
    static fetchUser = async () => {
        try {
            const response = await axios.get(`http://localhost:${ServicePort.port}/users/getAll`);
            console.log(response);
            return response.data;
        } catch (error) {
            console.error('Error fetching table data:', error);
            throw error;
        }
    };

    static async fetchEinform(searchParams) {
        try {
            const response = await axios.get(`http://localhost:${ServicePort.port}/easyNotify/search`, { params: searchParams });
            return response.data;
        } catch (error) {
            console.error('获取易告知信息时出错:', error);
            throw error;
        }
    }
    static async fetchAnnounce(searchParams) {
        try {
            console.log(searchParams);
            const response = await axios.get(`http://localhost:${ServicePort.port}/info/list`, { params: searchParams });
            return response.data;
        } catch (error) {
            console.error('获取公告信息时出错:', error);
            throw error;
        }
    }

    //用户管理
    static fetchTableData = async () => {
        try {
            const response = await axios.get(`http://localhost:${ServicePort.port}/roles/getAll`);
            console.log(response);
            return response.data;
        } catch (error) {
            console.error('Error fetching table data:', error);
            throw error;
        }
    };

    static async addAnnounce(announceData) {
        try {
            const response = await axios.post(`http://localhost:${ServicePort.port}/info`, announceData);
            console.log('添加公告成功');
            return true;
        } catch (error) {
            console.error('添加公告失败:', error);
            throw error;
        }
    }

    static async addMatter(matterData) {
        try {
            const response = await axios.post(`http://localhost:${ServicePort.port}/ReservationItem/addReservationItem`, matterData);
            console.log('添加可预约事项成功');
            return true;
        } catch (error) {
            console.error('添加可预约事项失败:', error);
            throw error;
        }
    }
    static async addEinform(einformData) {
        try {
            const response = await axios.post(`http://localhost:${ServicePort.port}/easyNotify/create`, einformData);
            console.log('添加易告知成功');
            return true;
        } catch (error) {
            console.error('添加易告知失败:', error);
            throw error;
        }
    }
    static async fetchComplaint(searchParams) {
        try {
            console.log(searchParams);
            const response = await axios.get(`http://localhost:${ServicePort.port}/complaint/list`, { params: searchParams });
            return response.data;
        } catch (error) {
            console.error('获取投诉信息时出错:', error);
            throw error;
        }
    }
    static async replayComplaints(Id) {
        try {
            console.log(Id);
            const response = await axios.get(`http://localhost:80/complaint/reply/list?id=${Id}`);
            return response.data;
        } catch (error) {
            console.error('获取投诉信息时出错:', error);
            throw error;
        }
    }
    static async replayConsults(Id) {
        try {
            console.log(Id);
            const response = await axios.get(`http://localhost:80/consultation/reply/${Id}`);
            return response.data;
        } catch (error) {
            console.error('获取投诉信息时出错:', error);
            throw error;
        }
    }
    static async fetchConsultations(searchParams) {
        try {
            console.log(searchParams);
            const response = await axios.get(`http://localhost:${ServicePort.port}/consultation/list`, { params: searchParams });
            return response.data;
        } catch (error) {
            console.error('获取咨询信息时出错:', error);
            throw error;
        }
    }
    static async fetchAppointments(searchParams) {
        try {
            console.log(searchParams);
            const response = await axios.get(`http://localhost:${ServicePort.port}/Reservation/search`, { params: searchParams });
            return response.data;
        } catch (error) {
            console.error('获取预约信息时出错:', error);
            throw error;
        }
    }
    static async fetchAppointment(searchParams){
        try{
            console.log(searchParams);
            const response = await axios.get(`http://localhost:${ServicePort.port}/Reservation/search`,{params:searchParams});
            return response.data;
        }catch (error){
            console.error('获取预约信息时出错：',error);
            throw error;
        }
    }
    static async fetchMatter(searchParams) {
        try {
            const response = await axios.get(`http://localhost:${ServicePort.port}/ReservationItem/search`, { params: searchParams });
            return response.data;
        } catch (error) {
            console.error('获取可预约事项信息时出错:', error);
            throw error;
        }
    }

    static async deleteMatter(reservationItemId) {
        try {
            console.log();
            const response = await axios.delete(`http://localhost:${ServicePort.port}/ReservationItem/delete/${reservationItemId}`);
            if (response.status === 200) {
                alert('删除成功');
            } else {
                alert('删除失败');
            }
        } catch (error) {
            console.error('删除可预约事项时出错:', error);
            throw error;
        }
    }
    static async deleteAnnounce(infoId) {
        try {
            console.log();
            const response = await axios.delete(`http://localhost:${ServicePort.port}/info/${infoId}`);
            if (response.status === 200) {
                alert('删除成功');
            } else {
                alert('删除失败');
            }
        } catch (error) {
            console.error('删除可预约事项时出错:', error);
            throw error;
        }
    }
    static async submitComplaint(complaintForm){
        try {
            console.log();
            const response = await axios.post(`http://localhost:${ServicePort.port}/complaint/`,complaintForm);
            if(response.status===200){
                alert('提交成功');
            }else{
                alert('提交失败');
            }
        }catch (error){
            console.error('提交投诉时出错',error);
            throw error;
        }
    }

    static async submitConsult(consultForm){
        try{
            console.log();
            const response = await axios.post(`http://localhost:${ServicePort.port}/consultation/`,consultForm);
            if(response.status===200){
                alert('提交成功');
            }else{
                alert('提交失败');
            }
        }catch (error){
            console.error('提交咨询时出错',error);
            throw error;
        }
    }
    static async submitAppointment(appointmentForm){
        try{
            console.log();
            const response = await axios.post(`http://localhost:${ServicePort.port}/Reservation/addReservation`,appointmentForm);
            if(response.status===200){
                alert('提交成功');
            }else{
                alert('提交失败');
            }
        }catch (error){
            console.error('提交预约时出错',error);
            throw error;
        }
    }

}

export default ServicePort;
