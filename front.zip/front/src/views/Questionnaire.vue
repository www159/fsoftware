<template>
  <div class="questionnaire-management">
    <!-- 标题栏 -->
    <div class="title-bar">
      <div class="title">问卷信息管理</div>
<!--      <div class="link" @click="openQuestionnaireDialog">新增问卷</div>-->
      <div class="link" @click="drawer = true">新增问卷</div>
    </div>
    <!-- 搜索栏 -->
    <el-row class="search-row">
      <el-col :span="7">
        <el-input v-model="searchTitle" placeholder="请输入问卷标题"></el-input>
      </el-col>
      <el-col :span="7">
        <el-date-picker v-model="searchDate" type="datetimerange" placeholder="选择日期"></el-date-picker>
      </el-col>

      <el-col :span="4" >
        <el-form-item>
          <el-select v-model.trim="questionnaireForm.questionnaireState" clearable placeholder="状态" >
            <el-option
                v-for="item in AcceptedOrNot"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="1">
        <el-button type="primary" @click="searchQuestionnaires">搜索</el-button>
      </el-col>
    </el-row>

    <!-- 问卷信息展示表格 -->
    <el-table :data="questionnaires" style="width: 100%">
      <el-table-column label="问卷标题" prop="title"></el-table-column>
      <el-table-column label="开始时间" prop="begindate"></el-table-column>
      <el-table-column label="结束时间" prop="enddate"></el-table-column>
      <el-table-column label="创建人" prop="name"></el-table-column>
      <el-table-column label="状态" prop="state"></el-table-column>
      <el-table-column label="操作">
        <template #default="{ row }">
          <el-button type="text" @click="viewQuestionnaire(row)">查看统计</el-button>
          <el-button type="text" @click="ChangeQuestionnaire(row)">停用/启用</el-button>
          <el-button type="text" @click="EditQuestionnaire(row)">编辑</el-button>
          <el-button type="text" @click="deleteQuestionnaire(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
<!--  <el-dialog  title="还没做好" v-model="QuestionnairedialogVisible">-->

<!--  </el-dialog>-->
  <el-drawer v-model="drawer" title="新建问卷">
    <div>
      <!-- 投诉表单 -->
      <el-form ref="questionnaireForm" :model="questionnaireForm" label-width="120px">
        <el-form-item label="问卷标题">
          <el-input v-model="questionnaireForm.questionnaireTitle"></el-input>
        </el-form-item>
        <el-form-item label="问卷开始时间">
          <el-date-picker v-model="questionnaireForm.questionnaireBeginDate" type="datetimerange" placeholder="选择日期"></el-date-picker>
        </el-form-item>
        <el-form-item label="问卷结束时间">
          <el-date-picker v-model="questionnaireForm.questionnaireEndDate" type="datetimerange" placeholder="选择日期"></el-date-picker>
        </el-form-item>
        <el-form-item label="是否有效">
          <el-select v-model.trim="questionnaireForm.questionnaireState" clearable placeholder="状态" >
            <el-option
                v-for="item in AcceptedOrNot"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="申请人">
          <el-input v-model="questionnaireForm.questionnaireTitle"></el-input>
        </el-form-item>
        <el-form-item label="申请部门">
          <el-input v-model="questionnaireForm.questionnaireDept"></el-input>
        </el-form-item>
        <el-form-item label="申请时间">
          <el-date-picker v-model="questionnaireForm.questionnaireDate" type="datetimerange" placeholder="选择日期"></el-date-picker>
        </el-form-item>
      </el-form>
      <div class="adjust" style="margin-top: -10px">问卷内容</div>
      <el-form ref="modelForm" :rules="rules" :model="modelForm" label-position="right" label-width="100px">
        <el-collapse>
          <el-collapse-item v-for="(item, index) in modelForm.topic" :key="index">
            <template #title>
              <span>第{{ index+1 }}题,题目:{{ item.questionName }}</span>
            </template>
            <!-- 问题类型 -->
            <el-form-item :prop="`topic.${index}.type`" :label="`问题${index + 1}类型`" :rules="[{ required: true, message: '请选择问题类型', trigger: 'change' }]">
              <el-radio-group v-model="item.type">
                <el-radio :label="0">单选题</el-radio>
                <el-radio :label="1">多选题</el-radio>
              </el-radio-group>
            </el-form-item>
            <!-- 问题内容 -->
            <el-form-item :prop="`topic.${index}.questionName`" label="问题" :rules="[{ required: true, message: '请填写问题', trigger: 'change' }]">
              <el-input v-model.trim="item.questionName" style="width:258px" clearable placeholder="请填写问题" />
            </el-form-item>
            <!-- 答案选项 -->
            <el-form-item v-for="(opt, idx) in item.answers" v-show="item.type !== 2" :key="idx" :label="`选项${idx + 1}`" :prop="`topic.${index}.answers.${idx}.value`" :rules="[{ required: true, message: '请输入答案', trigger: 'blur' }]">
              <el-input v-model.trim="opt.value" style="width:258px" clearable placeholder="请输入答案" />
              <el-button style="margin-left: 20px" @click.prevent="removeDomain(index, idx)">删除</el-button>
            </el-form-item>
            <el-form-item>
              <el-button v-show="item.type !== 2" @click="addDomain(index)">新增选项</el-button>
              <el-button @click="removeQuestion(index)">删除题目</el-button>
            </el-form-item>
          </el-collapse-item>
        </el-collapse>

        <el-form-item>
          <el-button @click="addQuestion">新增题目</el-button>
          <el-button @click="addSubmit()">提交</el-button>
          <el-button @click="resetForm('modelForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </el-drawer>
</template>

<script>

export default {
  name:'questionnaire',

  data() {
    return {
      drawer: false,
      rules: {},
      modelForm: {
        topic: [{
          type: '',
          questionName: '',
          answers: [{ value: '' }]
        }, {
          type: '',
          questionName: '',
          answers: [{ value: '' }]
        }]
      },
      searchTitle: '',
      searchDate: '',
      questionnaires: [
        { title: '问卷1', begindate: '2022-01-01' ,enddate:'2023-02-03',name:'小六',state:'已失效'},
        { title: '问卷2', begindate: '2022-02-05' ,enddate:'2023-04-05',name:'裴总',state:'有效'},
        { title: '问卷3', begindate: '2022-05-06' ,enddate:'2023-04-07',name:'启强',state:'有效'}
      ],
      questionnaireForm: { // 表单数据
        questionnaireTitle: '',
        questionnaireBeginDate:'',
        questionnaireEndDate:'',
        questionnaireState:'',
        questionnaireDept:'',
        questionnaireHuman:'',
        questionnaireDate:'',
        // 其他表单字段根据需要添加
      },
      QuestionnairedialogVisible: false,
      AcceptedOrNot:[
        {
          value: '有效',
          label: '有效',
        },
        {
          value: '已失效',
          label: '已失效',
        },
      ],
    };
  },
  methods: {
    searchQuestionnaires() {
      // 根据搜索条件执行搜索逻辑
    },
    viewQuestionnaire(questionnaire) {
      // 查看指定问卷的操作逻辑
    },
    ChangeQuestionnaire(questionnaire) {
      // 停用启用指定问卷的操作逻辑
    },
    EditQuestionnaire(questionnaire) {
      // 编辑指定问卷的操作逻辑
    },
    deleteQuestionnaire(questionnaire) {
      // 删除指定问卷的操作逻辑
    },
    // openQuestionnaireDialog() {
    //   this.QuestionnairedialogVisible = true;
    // },
    // submitQuestionnaireForm() {
    //
    //   this.QuestionnairedialogVisible = false;
    //   this.$refs.questionnaireForm.resetFields();
    // },
    end(evt) {
      this.$refs.modelForm.clearValidate()
    },
    removeDomain(index, idx) { // 删除选项
      this.modelForm.topic[index].answers.splice(idx, 1)
    },
    removeQuestion(index) {//删除题目
      this.modelForm.topic.splice(index, 1)
    },
    addDomain(index) { // 新增选项
      this.modelForm.topic[index].answers.push({ value: '' })
    },
    addQuestion() { // 新增题目
      this.modelForm.topic.push({ type: '', questionName: '', answers: [{ value: '' }] })
    },
    resetForm(formName) { // 重置
      this.$refs[formName].resetFields()
    },
    addSubmit() {
      this.$refs.modelForm.validate(valid => {
        if (valid) {
          console.log(this.modelForm.topic)
        }
      })
    }
  }
};
</script>

<style scoped>
.questionnaire-management {
  padding: 0;
}

.title {
  color: #000;
  font-size: 24px;
}

.search-row {
  margin-top: 10px;
  margin-bottom: 10px;
}
.title-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #f5f5f5;
}
.adjust{

}
</style>
