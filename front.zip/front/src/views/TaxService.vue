<template>
  <div class="container3">
    <div class="container1">
      <div class="con-button">
        <el-menu
            :default-active="activeIndex"
            class="el-menu-demo2"
            mode="horizontal"
            @select="handleSelect"
        >
          <el-menu-item @click="goToPersonalWorkspace" class="fontsize">个人空间</el-menu-item>
          <el-menu-item @click="goToTaxService" class="fontsize">纳税服务</el-menu-item>
        </el-menu>
      </div>
      <div>
        <div class="container2">
          <el-container class="taxservice_container">
            <!-- 侧边栏 -->
            <el-aside width="140px">
              <!-- 侧边栏菜单区域 -->
              <el-menu
                  class="el-menu-demo"
                  @select="handleSelect"
                  active-text-color="#ffd04b"
                  :default-active="activePath"
                  router>
                <!-- 一级菜单 -->
                <el-menu-item index="/taxservice/announce" @click="saveNavState('/taxservice/announce')">公告信息管理</el-menu-item>
                <el-menu-item index="/taxservice/complaint" @click="saveNavState('/taxservice/complaint')">投诉受理</el-menu-item>
                <el-menu-item index="/taxservice/consult" @click="saveNavState('/taxservice/consult')">纳税咨询</el-menu-item>
                <el-menu-item index="/taxservice/einform" @click="saveNavState('/taxservice/einform')">易告知</el-menu-item>
                <el-menu-item index="/taxservice/appointment" @click="saveNavState('/taxservice/appointment')">服务预约</el-menu-item>
<!--                <el-menu-item index="/taxservice/questionnaire" @click="saveNavState('/taxservice/complaint')">服务调查</el-menu-item>-->
                <el-menu-item index="/taxservice/questionnaire" @click="goTo">服务调查</el-menu-item>
              </el-menu>
            </el-aside>
            <!-- 右侧内容主体区域 -->
            <el-main>
              <router-view></router-view>
            </el-main>
          </el-container>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name:"taxservice",
  data(){
    return{
      // 被激活高亮的链接地址
      activePath: '/taxservice/announce'
    }
  },
  methods:{
    // 保存链接的激活状态
    saveNavState (activePath) {
      window.sessionStorage.setItem('activePath', activePath)
      this.activePath = window.sessionStorage.getItem('activePath')
    },
    goToPersonalWorkspace() {
      this.$router.push('/myworkspace');
    },
    goToTaxService() {
      this.$router.push('/taxservice/announce');
    },
    goTo() {
      window.open('http://localhost/survey/admin/', '_blank')
    }
  }
};
</script>

<style scoped>
.container1 {
  padding: 90px;
  margin: 10px 475px;
}
.container2 {
  height: 70vh;
  width: 80vw;
  display: flex;
  flex-direction: column;
}
.container3{
  background-image: url('../assets/444plus.png');
  background-size: 1900px 915px;
  background-repeat: no-repeat; /* 禁止背景图重复 */
  background-position: center; /* 将背景图居中对齐 */
  background-attachment: fixed;
}
.taxservice_container{
  margin-top: 30px;
  width: 1713px;
  background-color: #f0f0f0;
  padding: 20px;
  margin-left: -480px;
}
.con-button {
  position: relative;
  right: 480px;
  top:20px;
}
.el-menu-demo{
  margin-top: 20px;
  margin-left: 15px;
}
.fontsize{
  font-size: 16px;
}
</style>
