<template>
  <div class="einform-management">
    <!-- 标题栏 -->
    <div class="title-bar">
      <div class="title">易告知信息管理</div>
      <div class="link" @click="openEinformDialog">新增易告知</div>
    </div>
    <!-- 搜索栏 -->
    <el-row class="search-row">
      <el-col :span="7">
        <el-input v-model="search.title" placeholder="请输入易告知标题"></el-input>
      </el-col>
      <el-col :span="3" >
        <el-form-item>
          <el-select v-model.trim="search.type" clearable placeholder="类型" >
            <el-option
                v-for="item in Type"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="4" >
        <el-form-item>
          <el-select v-model.trim="search.status" clearable placeholder="状态" >
            <el-option
                v-for="item in AcceptedOrNot"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-col>

      <el-col :span="1">
        <el-button type="primary" @click="searchEinforms">搜索</el-button>
      </el-col>
    </el-row>

    <!-- 易告知信息展示表格 -->
    <el-table :data="einforms" style="width: 100%">
      <el-table-column label="易告知id" prop="id"></el-table-column>
      <el-table-column label="易告知标题" prop="title"></el-table-column>
      <el-table-column label="类型" prop="type"></el-table-column>
      <el-table-column label="创建人" prop="creator"></el-table-column>
      <el-table-column label="创建时间" prop="createdTime"></el-table-column>
      <el-table-column label="状态" prop="status"></el-table-column>
      <el-table-column label="上传">
        <el-upload  :action="'http://localhost:80/easyNotify/import'" :show-file-list="false" accept="xlsx" :on-success="importSuccess">
          <el-button type="primary" class="ml-5" style="width: 155px;height: 27px;">上传文件<i class="el-icon-bottom"></i></el-button>
        </el-upload>
      </el-table-column>
      <el-table-column label="操作">
        <template #default="{ row }">
          <el-button type="text" @click="viewEinform(row)">查看发送记录</el-button>
          <el-button type="text" @click="ChangeEinform(row)">
            {{ row.status === '停用' ? '启用' : '' }}
          </el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
  <el-dialog  title="新增易告知" v-model="EinformdialogVisible">
    <!-- 投诉表单 -->
    <el-form ref="einformForm" :model="einformForm" label-width="100px">
      <el-form-item label="易告知标题">
        <el-input v-model="einformForm.einformTitle"></el-input>
      </el-form-item>
      <el-form-item label="易告知类型">
        <el-select v-model.trim="einformForm.einformType" clearable placeholder="类型" >
          <el-option
              v-for="item in Type"
              :key="item.value"
              :label="item.label"
              :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="易告知内容">
        <el-input v-model="einformForm.einformContent" type="textarea"></el-input>
      </el-form-item>
      <el-form-item label="易告知状态">
        <el-select v-model.trim="einformForm.einformState" clearable placeholder="状态" >
          <el-option
              v-for="item in AcceptedOrNot"
              :key="item.value"
              :label="item.label"
              :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="创建人">
        <el-input v-model="einformForm.einformHuman"></el-input>
      </el-form-item>
      <el-form-item label="创建时间">
        <el-date-picker v-model="einformForm.einformDate" type="date" placeholder="选择日期"></el-date-picker>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitEinformForm">提交</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
  <el-dialog title="易告知发送邮件记录" v-model="maildialogVisible" style="width: 700px">
    <el-table :data="mails" style="width: 700px">
      <el-table-column label="易告知id" prop="notifyId" style="width: 300px"></el-table-column>
      <el-table-column label="发送邮箱" prop="mail" style="width: 300px"></el-table-column>
    </el-table>
    <div slot="footer" class="dialog-footer" style="width: 100px">
      <el-button @click="maildialogVisible = false">关闭</el-button>
    </div>
  </el-dialog>
</template>

<script>
import axios from "axios";
import ServicePort from "@/views/ServicePort";

export default {
  name:'einform',
  data() {
    return {
      maildialogVisible: false,
      search: {
        title: '',
        type: '',
        status:'',
      },
      mails:[],
      einforms: [],
      einformForm: { // 表单数据
        einformTitle: '',
        einformContent: '',
        einformDate:'',
        einformType:'',
        einformWay:'',
        einformState:'',
        einformHuman:'',
        // 其他表单字段根据需要添加
      },
      EinformdialogVisible: false,
      AcceptedOrNot:[
        {
          value: '启用',
          label: '启用',
        },
        {
          value: '停用',
          label: '停用',
        },
      ],
      Type:[
        {
          value: '催办',
          label: '催办',
        },
        {
          value: '催缴',
          label: '催缴',
        },
      ],
    };
  },
  mounted() {
    this.fetchEinform();
  },
  methods: {
    async fetchEinform() {
      try {
        const searchParams = {
          title:this.search.title ,
          type:this.search.type,
          status:this.search.status,
        };
        const einforms = await ServicePort.fetchEinform(searchParams);
        this.einforms = einforms;
      } catch (error) {
        // 处理错误
      }
    },
    async ChangeEinform(row) {
      try {
        const notifyId = row.id;
        const newState = {
          status: '启用',
        }
        console.log(notifyId,newState);
        const response1 = await axios.put(`http://localhost:80/easyNotify/${notifyId}/status?status=${newState.status}`);
        if (response1.status === 200) {
          // Update the state locally
          this.fetchEinform();
        } else {
          // Handle the response error
        }
        if (row.type==='催办') {
          const response2 = await axios.post(`http://localhost:80/easyNotify/sendEmail/cuiban?notifyId=${notifyId}`);
          if (response2.status === 200) {
            alert('发送邮件成功');
            // Update the state locally
            this.fetchEinform();
          } else {
            // Handle the response error
          }
        }else if(row.type==='催缴'){
          const response2 = await axios.post(`http://localhost:80/easyNotify/sendEmail/cuijiao?notifyId=${notifyId}`);
          if (response2.status === 200) {
            alert('发送邮件成功');
            // Update the state locally
            this.fetchEinform();
          } else {
            // Handle the response error
          }
        }
      } catch (error) {
        // Handle the error
      }
    },
    searchEinforms() {
      this.fetchEinform();
    },
    async viewEinform(row) {
      this.maildialogVisible = true;
      try {
        const notifyId = row.id;
        const response = await axios.get(`http://localhost:80/easyNotify/getEmails/${notifyId}`);
        this.mails = response.data
        if (response.status === 200) {
          // Update the state locally
        } else {
          // Handle the response error
        }
      } catch (error) {
        // Handle the error
      }
    },
    deleteEinform(einform) {
      // 删除指定易告知的操作逻辑
    },
    openEinformDialog() {
      this.EinformdialogVisible = true;
    },
    async submitEinformForm() {
      try {
        const einformData = {
          title: this.einformForm.einformTitle,
          type: this.einformForm.einformType,
          createdTime:this.einformForm.einformDate,
          status: this.einformForm.einformState,
          creator:this.einformForm.einformHuman,
        };
        await ServicePort.addEinform(einformData);
        this.einformForm = {
          einformTitle: '',
          einformType: '',
          einformDate: '',
          einformState: '',
          einformHuman:''
        };
        this.EinformdialogVisible = false;
        this.fetchEinform();
      } catch (error) {
        // 处理错误
      }
    },
    importSuccess() {
      alert('导入成功');
    },
  }
};
</script>

<style scoped>
.einform-management {
  padding: 0;
}

.title {
  color: #000;
  font-size: 24px;
}

.search-row {
  margin-top: 10px;
  margin-bottom: 10px;
}
.title-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #f5f5f5;
}
</style>

