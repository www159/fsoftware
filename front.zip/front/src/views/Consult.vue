<template>
  <div class="consult-management">
    <!-- 标题栏 -->
    <div class="title-bar">
      <div class="title">咨询信息处理</div>
    </div>
    <!-- 搜索栏 -->
    <el-row class="search-row">
      <el-col :span="7">
        <el-input v-model="search.title" placeholder="请输入咨询标题"></el-input>
      </el-col>
      <el-col :span="7">
        <el-date-picker v-model="search.time" type="datetimerange" placeholder="选择日期"></el-date-picker>
      </el-col>
      <el-col :span="4" >
        <el-form-item>
          <el-select v-model.trim="search.state" clearable placeholder="状态" >
            <el-option
                v-for="item in AcceptedOrNot"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="1">
        <el-button type="primary"  @click.native="searchConsultations" >搜索</el-button>
      </el-col>

    </el-row>

    <!-- 咨询信息展示表格 -->
    <el-table :data="consults" style="width: 100%">
      <el-table-column label="咨询标题" prop="title"></el-table-column>
      <el-table-column label="咨询人单位" prop="company"></el-table-column>
      <el-table-column label="咨询人" prop="name"></el-table-column>
      <el-table-column label="手机号码" prop="mobile"></el-table-column>
      <el-table-column label="咨询时间" prop="time" ></el-table-column>
      <el-table-column label="状态" prop="state">
        <template #default="{ row }">
          {{ statusMappings[row.state] }}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template #default="{ row }">
          <el-button type="text" @click="viewConsult(row)">{{ row.state === 0? '处理' : '' }}</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
  <el-dialog title="咨询处理" v-model="consultDialogVisible">
    <div>
      <p style="font-size: 20px;"><strong>咨询标题：</strong>{{ selectedConsult.title }}</p>
      <p style="font-size: 18px;"><strong>咨询内容：</strong>{{ selectedConsult.content }}</p>

      <el-form ref="replyForm" :model="replyForm" label-width="80px">
        <el-form-item label="回复">
          <el-input type="textarea" v-model="replyForm.replyContent" rows="3"></el-input>
        </el-form-item>
        <el-form-item label="处理日期">
          <el-date-picker v-model="replyForm.time" type="date" placeholder="选择日期"></el-date-picker>
        </el-form-item>
      </el-form>
    </div>

    <div slot="footer" class="dialog-footer">
      <el-button @click="cancelConsult">取消</el-button>
      <el-button type="primary" @click="completeConsult">完成</el-button>
    </div>
  </el-dialog>
</template>

<script>
import axios from "axios";
import ServicePort from './ServicePort';
export default {
  name:'consult',
  data() {
    return {
      // searchTitle: '',
      // searchDate: '',
      // searchState:'',
      consults: [],
      statusMappings: {
        '0': '未处理',
        '1': '已处理',
        '2': '失效',
      },
      search: {
        title: '',//查询部门
        time: '', // 查询参数
        state:'',
      },
      selectedConsult: {
        title: '',
        content: '',
      },
      currentEditConsult: null,
      replyForm: {
        replyContent: ''
      },
      consultDialogVisible: false,
      consultForm: { // 咨询表单数据
        consultNumber: '',
        consultTitle: '',
        consultContent: '',
        consultDate:'',
        consultState:'',
        // 其他表单字段根据需要添加
      },
      AcceptedOrNot:[
        {
          value: '1',
          label: '已处理',
        },
        {
          value: '0',
          label: '未处理',
        },
      ],
    };
  },
  mounted() {
    this.fetchConsultations();
  },
  methods: {

    async fetchConsultations() {
      try {
        const searchParams = {
          title: this.search.title,
          startDate: this.search.time[0], // 开始日期
          endDate: this.search.time[1],   // 结束日期
          state: this.search.state,
        };
        const consultations = await ServicePort.fetchConsultations(searchParams);
        this.consults = consultations;
      } catch (error) {
        // 处理错误
      }
    },
    searchConsultations() {
      this.fetchConsultations();
    },

    viewConsult(row) {
      this.currentEditConsult = row;
      // 将公告信息填充到编辑表单中
      this.selectedConsult.title = row.title;
      this.selectedConsult.content = row.content;
      this.selectedConsult.consultationId = row.consultationId
      // 打开编辑对话框
      this.consultDialogVisible = true;
    },
    cancelConsult() {
      this.replyForm.content = '';
      this.consultDialogVisible = false;
    },
    async completeConsult(){
      try {
        const consultData = {
          content: this.replyForm.replyContent,
          consultationId:this.selectedConsult.consultationId,
          replyerId:this.$store.getters.id,
          time:this.replyForm.time,
        };
        console.log(consultData);
        // 发送请求更新公告信息
        await axios.post(`http://localhost:80/consultation/reply`, consultData);

        // 清空编辑表单
        this.replyForm.replyContent = '';
        this.replyForm.time = '';
        alert('处理咨询成功');
        // 关闭编辑对话框
        this.consultDialogVisible = false;
        // 重新获取公告列表
        this.fetchConsultations();
      } catch (error) {
        // 处理错误
      }
    },
  }
};
</script>

<style scoped>
.consult-management {
  padding: 0;
}

.title {
  color: #000;
  font-size: 24px;
}

.search-row {
  margin-top: 10px;
  margin-bottom: 10px;
}
.title-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #f5f5f5;
}
</style>
