<template>
  <div class="container3">
    <div class="container1">
      <div class="con-button">
        <el-menu
            :default-active="activeIndex"
            class="el-menu-demo2"
            mode="horizontal"
            @select="handleSelect"
        >
          <el-menu-item @click="goToPersonalWorkspace" class="fontsize">个人空间</el-menu-item>
          <el-menu-item @click="goToTaxService" class="fontsize">{{ this.$store.getters.roleId===1?'纳税服务':''}}</el-menu-item>
        </el-menu>
      </div>
      <div>
        <div class="container2">
          <div class="top-half">

            <div class="personal-info">
              <div class="avatar">
                <!-- 这里是用户头像的图片 -->
                <img src="../assets/333.jpg" alt="个人头像">
              </div>
              <div class="user-info">
                <div class="name">姓名：{{name}}</div>
                <div class="department">部门：{{dept}}</div>
                <div class="employee-id">工号：{{account}}</div>
              </div>
            </div>
            <div class="announcement">
              <div class="title-bar">
                <div class="title1">公告栏</div>
                <div class="link" @click="showMore">更多+</div>
              </div>

              <div class="announcement-list">
                <ul>
                  <el-table :data="filteredAnnouncements.slice(0, 3)" style="width: 100%" >
                    <el-table-column label="公告标题" prop="title" ></el-table-column>
                    <el-table-column label="日期" prop="time" :formatter="formatDate"></el-table-column>
                    <el-table-column label="操作" >
                      <template #default="{ row }">
                        <el-button type="text" @click="viewAnnouncement(row)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </ul>
              </div>
              <el-dialog title="更多公告" v-model="moreDialogVisible" width="800px">
                <el-table :data="filteredAnnouncements" style="width: 95%" >
                  <el-table-column label="公告标题" prop="title" width="300px"></el-table-column>
                  <el-table-column label="日期" prop="time" width="300px" :formatter="formatDate "></el-table-column>
                  <el-table-column label="操作" width="200px">
                    <template #default="{ row }">
                      <el-button type="text" @click="viewAnnouncement(row)">查看</el-button>
                    </template>
                  </el-table-column>
                </el-table>
              </el-dialog>
            </div>
          </div>

          <div class="bottom-half">
            <div class="sidebar">
              <el-menu default-active="1" @select="handleMenuSelect">
                <el-menu-item index="1" @click="fetchComplaint">我的投诉</el-menu-item>
                <el-menu-item index="2" @click="fetchAppointment">我的预约</el-menu-item>
                <el-menu-item index="3" @click="fetchConsultations">我的咨询</el-menu-item>
                <el-menu-item index="4" @click="goTo">服务调查</el-menu-item>
              </el-menu>
            </div>
            <!-- 右侧内容区域 -->
            <div class="content">
              <div v-if="activeTab === 'complaints'">
                <div>
                  <!-- 标题栏 -->
                  <div class="title-bar">
                    <div class="title2">我的投诉</div>
                    <div class="link" @click="openComplaintDialog">我要投诉</div>
                  </div>
                  <div class="complaintsadjust">
                    <!-- 投诉表格 -->
                    <el-table :data="filteredComplaints" style="width: 100%">
                      <el-table-column prop="complaintId" label="投诉编号"></el-table-column>
                      <el-table-column prop="title" label="投诉标题"></el-table-column>
                      <el-table-column label="状态" prop="state">
                        <template #default="{ row }">
                          {{ statusMappings[row.state] }}
                        </template>
                      </el-table-column>
                      <el-table-column prop="time" label="投诉日期"></el-table-column>
                      <el-table-column label="操作">
                        <template #default="row">
                          <el-button type="text" @click="viewComplaint(row)">{{ row.row.state===1?'查看':'' }}</el-button>
                        </template>
                      </el-table-column>
                    </el-table>

                    <!-- 投诉对话框 -->
                    <el-dialog  title="我要投诉" v-model="ComplaintdialogVisible">
                      <!-- 投诉表单 -->
                      <el-col :span="23">
                        <el-form ref="complaintForm" :model="complaintForm" label-width="100px">

                          <el-form-item label="投诉标题">
                            <el-input v-model="complaintForm.title"></el-input>
                          </el-form-item>
                          <el-form-item label="投诉人公司">
                            <el-input v-model="complaintForm.complaintCompany"></el-input>
                          </el-form-item>
                          <el-form-item label="投诉人姓名">
                            <el-input v-model="complaintForm.complaintName"></el-input>
                          </el-form-item>
                          <el-form-item label="投诉人电话">
                            <el-input v-model="complaintForm.mobile"></el-input>
                          </el-form-item>
                          <el-form-item label="投诉日期">
                            <el-date-picker v-model="complaintForm.time" type="date" placeholder="选择日期"></el-date-picker>
                          </el-form-item>
                          <el-form-item label="投诉内容">
                            <el-input v-model="complaintForm.content" type="textarea"></el-input>
                          </el-form-item>
                          <el-form-item label="被投诉人姓名">
                            <el-input v-model="complaintForm.toComplaintName"></el-input>
                          </el-form-item>
                          <el-form-item label="被投诉人部门">
                            <el-input v-model="complaintForm.toComplaintDept"></el-input>
                          </el-form-item>
                          <!--国税局投诉通常要求实名投诉qwq
                            <el-form-item label="匿名情况">
                              <el-select v-model.trim="complaintForm.isAnonymous" clearable placeholder="是否匿名" >
                                <el-option
                                v-for="item in anonymousOrNot"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value"
                            />
                          </el-select>
                            </el-form-item>
                            -->
                          <!-- 其他表单项根据需要添加 -->
                          <!-- 提交按钮 -->
                          <el-form-item>
                            <el-button type="primary" @click="submitComplaintForm">提交</el-button>
                          </el-form-item>
                        </el-form>
                      </el-col>
                    </el-dialog>
                  </div>
                </div>
              </div>
              <div v-else-if="activeTab === 'appointments'">
                <!-- 我的预约界面的具体内容 -->
                <div>
                  <!-- 标题栏 -->
                  <div class="title-bar">
                    <div class="title2">我的预约</div>
                    <div class="link" @click="openAppointmentDialog">我要预约</div>
                  </div>
                  <div class="complaitsadjust">
                    <!-- 预约表格 -->
                    <el-table :data="filteredAppointments" style="width: 100%">
                      <el-table-column prop="name" label="预约事项"></el-table-column>
                      <el-table-column prop="state" label="预约状态">
                        <template #default="{ row }">
                          {{ statusMappings3[row.state] }}
                        </template>
                      </el-table-column>
                      <el-table-column prop="reserveName" label="预约人姓名"></el-table-column>
                      <el-table-column prop="reservationTime" label="预约时间"></el-table-column>
                      <!-- 其他列字段根据实际需要添加 -->


                    </el-table>

                    <!-- 预约对话框 -->
                    <el-dialog  title="我要预约" v-model="AppointmentdialogVisible">
                      <!-- 预约表单 -->
                      <el-col :span="23">
                        <el-form ref="appointmentForm" :model="appointmentForm" label-width="100px">
                          <el-form-item label="预约事项">
                            <el-select v-model="appointmentForm.reservationItemId" class="m-2" placeholder="选择预约事项类型">
                              <el-option
                                  v-for="item in appointmentTypes"
                                  :key="item.value"
                                  :label="item.label"
                                  :value="item.value"
                              />
                            </el-select>
                          </el-form-item>
                          <el-form-item label="预约时间">
                            <el-date-picker v-model="appointmentForm.reservationTime" type="datetime" placeholder="选择日期"></el-date-picker>
                          </el-form-item>
                          <el-form-item label="预约人姓名">
                            <el-input v-model="appointmentForm.reserveName" ></el-input>
                          </el-form-item>
                          <el-form-item label="联系电话">
                            <el-input v-model="appointmentForm.reservePhoneNumber" ></el-input>
                          </el-form-item>
                          <!-- 其他表单项根据需要添加 -->

                          <!-- 提交按钮 -->
                          <el-form-item>
                            <el-button type="primary" @click="submitAppointmentForm">提交</el-button>
                          </el-form-item>
                        </el-form>
                      </el-col>
                    </el-dialog>
                  </div>
                </div>
              </div>
              <div v-else-if="activeTab === 'consult'">
                <!-- 我的咨询界面的具体内容 -->
                <div>
                  <!-- 标题栏 -->
                  <div class="title-bar">
                    <div class="title2">我的咨询</div>
                    <div class="link" @click="openConsultDialog">我要咨询</div>
                  </div>
                  <div class="complaitsadjust">
                    <!-- 咨询表格 -->
                    <el-table :data="filteredConsultations" style="width: 100%">
                      <el-table-column prop="consultationId" label="咨询编号"></el-table-column>
                      <el-table-column prop="title" label="咨询标题"></el-table-column>
                      <el-table-column label="状态" prop="state">
                        <template #default="{ row }">
                          {{ statusMappings2[row.state] }}
                        </template>
                      </el-table-column>
                      <el-table-column prop="time" label="咨询时间"></el-table-column>
                      <!-- 其他列字段根据实际需要添加 -->

                      <!-- 操作列 -->
                      <el-table-column label="操作">
                        <template #default="row">
                          <el-button type="text" @click="viewConsult(row)">{{ row.row.state===1?'查看':'' }}</el-button>
                        </template>
                      </el-table-column>
                    </el-table>

                    <!-- 对话框 -->
                    <el-dialog  title="我要咨询" v-model="ConsultdialogVisible">
                      <!-- 表单 -->
                      <el-col :span="23">
                        <el-form ref="consultForm" :model="consultForm" label-width="100px">
                          <el-form-item label="咨询类型">
                            <el-select v-model="consultForm.type" class="m-2" placeholder="选择咨询类型">
                              <el-option
                                  v-for="item in consultTypes"
                                  :key="item.value"
                                  :label="item.label"
                                  :value="item.value"
                              />
                            </el-select>
                          </el-form-item>
                          <el-form-item label="咨询标题">
                            <el-input v-model="consultForm.title"></el-input>
                          </el-form-item>
                          <el-form-item label="咨询人单位">
                            <el-input v-model="consultForm.company"></el-input>
                          </el-form-item>
                          <el-form-item label="咨询人姓名">
                            <el-input v-model="consultForm.name"></el-input>
                          </el-form-item>
                          <el-form-item label="咨询人电话">
                            <el-input v-model="consultForm.mobile"></el-input>
                          </el-form-item>
                          <el-form-item label="咨询日期">
                            <el-date-picker v-model="consultForm.time" type="date" placeholder="选择日期"></el-date-picker>
                          </el-form-item>
                          <el-form-item label="咨询内容">
                            <el-input v-model="consultForm.content" type="textarea"></el-input>
                          </el-form-item>
                          <!-- 其他表单项根据需要添加 -->

                          <!-- 提交按钮 -->
                          <el-form-item>
                            <el-button type="primary" @click="submitConsultForm">提交</el-button>
                          </el-form-item>
                        </el-form>
                      </el-col>
                    </el-dialog>
                  </div>
                </div>
              </div>
              <div v-else-if="activeTab === 'questionnaire'">
                <!-- 我的咨询界面的具体内容 -->
                <div>
                  <!-- 标题栏 -->
                  <div class="title-bar">
                    <div class="title2">调查问卷</div>
                  </div>
                  <div class="complaitsadjust">
                    <!-- 咨询表格 -->
                    <el-table :data="consults" style="width: 100%">
                      <el-table-column prop="questionnaireNumber" label="问卷编号"></el-table-column>
                      <el-table-column prop="questionnaireTitle" label="问卷标题"></el-table-column>
                      <el-table-column prop="questionnaireDate" label="日期"></el-table-column>
                      <el-table-column prop="questionnaireStatus" label="问卷状态"></el-table-column>
                      <el-table-column label="操作">
                        <template #default="{ row }">
                          <el-button type="text" @click="ManageQuestionnaire(row)">填写</el-button>
                        </template>
                      </el-table-column>
                      <!-- 其他列字段根据实际需要添加 -->
                      <!-- 操作列 -->
                    </el-table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <el-dialog title="公告详情" v-model="viewdialogVisible">
    <div class="announcement-details">
      <h1 class="announcement-title">{{ detail.title }}</h1>
      <p class="announcement-time">{{ detail.time}}</p>
      <div class="announcement-content">{{ detail.content }}</div>
    </div>
    <!-- 根据需要添加更多详细信息 -->
  </el-dialog>
  <el-dialog title="投诉处理" v-model="complaintReplyDialogVisible">
    <div>
      <p style="font-size: 18px;"><strong>投诉回复：</strong>{{complaintreplys[0].content}}</p>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="offComplaint">关闭</el-button>
    </div>
  </el-dialog>

  <el-dialog title="咨询处理" v-model="consultReplyDialogVisible">
    <div>
      <p style="font-size: 18px;"><strong>咨询回复：</strong>{{consultreplys.content}}</p>
    </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="offConsult">关闭</el-button>
    </div>
  </el-dialog>
</template>

<script>

import ServicePort from "@/views/ServicePort";

export default {
  name:'myworkspace',
  data() {
    return {
      account:this.$store.getters.account,
      dept:this.$store.getters.dept,
      name:this.$store.getters.name,
      id:this.$store.getters.id,
      statusMappings: {
        '0': '未受理',
        '1': '已受理',
        '2': '失效',
      },
      statusMappings2: {
        '0': '未处理',
        '1': '已处理',
        '2': '失效',
      },
      statusMappings3: {
        '0': '未处理',
        '1': '预约成功',
        '2': '预约失败',
      },
      activeTab: 'complaints',
      viewdialogVisible:false,
      complaintReplyDialogVisible:false,
      consultReplyDialogVisible:false,
      selectedComplaint: {
        title: '',
        content: '',
        reply: ''
      },
      announcements: [
      ],
      displayedNotices: [], // 用于展示的公告标题
      moreDialogVisible: false, // 控制更多公告窗口的显示和隐藏
      complaints: [], // 存储已发起的投诉信息
      complaintreplys:[{content:''}],
      consultreplys:{content:''},
      ComplaintdialogVisible: false, // 控制投诉对话框的显示和隐藏
      complaintForm: { // 投诉表单数据
        complaintCompany: '',
        complaintName: '',
        userId: this.$store.getters.id,
        mobile: '',
        anonymous: false,
        time: '',
        title: '',
        toComplaintName: '',
        toComplaintDept: '',
        content: '',
        state: 0 // 默认为未处理状态

        // 其他表单字段根据需要添加
      },
      // anonymousOrNot:[
      //   {
      //     value: '是',
      //     label: '是',
      //   },
      //   {
      //     value: '否',
      //     label: '否',
      //   },
      // ],
      consults: [], // 存储已发起的投诉信息
      ConsultdialogVisible: false, // 控制投诉对话框的显示和隐藏
      consultForm: { // 咨询表单数据
        consultId:this.$store.getters.id,
        time:'',
        title:'',
        type:'',
        state:0,
        name:'',
        mobile:'',
        company:'',
        content:'',
      },
      appointments: [], // 存储已发起的投诉信息
      AppointmentdialogVisible: false, // 控制投诉对话框的显示和隐藏
      appointmentForm: { // 投诉表单数据
        name: '',
        reservationTime: '',
        reservePhoneNumber:'',
        reservationItemId:'',
        reserveName:'',
        state:0,
        submitterId:this.$store.getters.id,
        reserveCompany:'',
        memo:'',
        // 其他表单字段根据需要添加
      },

      value: '',
      appointmentTypes: [
        {
          value: '2',
          label: '税务申报与缴纳',
        },
        {
          value: '3',
          label: '税务登记与变更',
        },
        {
          value: '1',
          label: '发票管理',
        },
        {
          value: '4',
          label: '税收优惠申请',
        },
      ],
      consultTypes:[
        {
          value: 0,
          label: '纳税政策咨询',
        },
        {
          value: 1,
          label: '税务申报咨询',
        },
        {
          value: 2,
          label: '税务争议解决咨询',
        },
      ]
    }
  },
  computed: {
    filteredAnnouncements() {
      return this.announcements.filter(data => data.state === 1);

    },
    filteredComplaints(){
      return this.complaints.filter(data => data.userId === this.$store.getters.id);
    },
    filteredConsultations(){
      return this.consults.filter(data => data.consultId === this.$store.getters.id);
    },
    filteredAppointments(){
      return this.appointments.filter(data => data.submitterId === this.$store.getters.id);
    },
  },

  mounted() {
    this.displayedNotices = this.filteredAnnouncements.slice(0, 3); // 默认展示前四个公告标题
    this.fetchComplaint();
    this.fetchAnnounce();
    this.fetchAppointment();
    this.fetchConsultations();
  },

  methods: {
    async fetchConsultations() {
      try {
        const searchParams = {
        };
        const consultations = await ServicePort.fetchConsultations(searchParams);
        this.consults = consultations;
      } catch (error) {
        // 处理错误
      }
    },
    async fetchAppointment() {
      try {
        const searchParams = {
        };
        const appointments = await ServicePort.fetchAppointment(searchParams);
        this.appointments = appointments;
      } catch (error) {
        // 处理错误
      }
    },
    async fetchAnnounce() {
      try {
        const searchParams = {
        };
        const announcements = await ServicePort.fetchAnnounce(searchParams);
        this.announcements = announcements;
      } catch (error) {
        // 处理错误
      }
    },
    async fetchComplaint() {
      try {
        const searchParams = {
        };
        const complaints = await ServicePort.fetchComplaint(searchParams);
        this.complaints = complaints;
      } catch (error) {
        // 处理错误
      }
    },
    async replyComplaint(Id) {
      try {
        const complaintreplys = await ServicePort.replayComplaints(Id);
        this.complaintreplys = complaintreplys;
        console.log(complaintreplys[0].content);
      } catch (error) {
        // 处理错误
      }
    },
    async replyConsult(Id) {
      try {
        const consultreplys = await ServicePort.replayConsults(Id);
        this.consultreplys = consultreplys;
        console.log(consultreplys.content);
      } catch (error) {
        // 处理错误
      }
    },
    handleMenuSelect(index) {
      if (index === '1') {
        // 切换到我的投诉界面
        this.activeTab = 'complaints';
      } else if (index === '2') {
        // 切换到我的预约界面
        this.activeTab = 'appointments';
      }else if (index === '3') {
        // 切换到我的预约界面
        this.activeTab = 'consult';
      }
      // else if (index === '4') {
      //   // 切换到我的预约界面
      //   this.activeTab = 'questionnaire';
      // }

    },
    formatDate(row, column) {
      const date = new Date(row.time);
      const year = date.getFullYear();
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const day = date.getDate().toString().padStart(2, '0');
      return `${year}-${month}-${day}`;
    },
    openComplaintDialog() {
      this.ComplaintdialogVisible = true;
    },
    submitComplaintForm() {
      // 提交投诉表单的逻辑，可以发送请求到后端保存投诉数据
      // ...
      ServicePort.submitComplaint(this.complaintForm);
      // 提交成功后，关闭对话框并清空表单数据
      this.fetchComplaint();
      this.ComplaintdialogVisible = false;

    },
    viewAnnouncement(row) {
      console.log(row);
      this.detail = row
      this.viewdialogVisible = true;
    },
    viewComplaint(row) {
      console.log(row.row.complaintId);
      this.replyComplaint(row.row.complaintId)
      this.complaintReplyDialogVisible = true;
    },
    offComplaint(){
      this.complaintReplyDialogVisible = false;
    },
    offConsult(){
      this.consultReplyDialogVisible = false;

    },
    openConsultDialog() {
      this.ConsultdialogVisible = true;
    },

    submitConsultForm() {
      ServicePort.submitConsult(this.consultForm);
      this.ConsultdialogVisible = false;
      this.fetchConsultations();
      this.$refs.consultForm.resetFields();
    },
    viewConsult(row) {
      console.log(row.row.consultationId);
      this.replyConsult(row.row.consultationId)
      this.consultReplyDialogVisible = true;
    },
    openAppointmentDialog() {
      this.AppointmentdialogVisible = true;
    },
    submitAppointmentForm() {
      ServicePort.submitAppointment(this.appointmentForm);
      this.AppointmentdialogVisible = false;
      this.fetchAppointment();
      this.$refs.appointmentForm.resetFields();
    },


    showMore() {
      this.moreDialogVisible = true;
    },
    goToPersonalWorkspace() {
      this.$router.push('/myworkspace');
    },
    goToTaxService() {
      this.$router.push('/taxservice/announce');
    },
    ManageQuestionnaire(questionnaire) {
      // 查看指定公告的操作逻辑
    },
    goTo() {
      window.open('http://localhost/survey/', '_blank')
    }
  }
};
</script>


<style scoped>
.container1 {
  padding: 90px;
  margin: 10px 475px;
}
.container2 {
  height: 70vh;
  width: 80vw;
  display: flex;
  flex-direction: column;
}
.container3{
  background-image: url('../assets/444plus.png');
  background-size: 1900px 915px;
  background-repeat: no-repeat; /* 禁止背景图重复 */
  background-position: center; /* 将背景图居中对齐 */
  background-attachment: fixed;
}
.con-button {
  position: relative;
  right: 480px;
  top:20px;
}

.top-half {
  margin-top: 30px;
  flex: 1;
  display: flex;
  margin-right: 300px;
  margin-left: -480px;
}

.bottom-half {
  margin-bottom: 10px;
  flex: 2;
  display: flex;
  margin-right: 300px;
  margin-left: -480px;
}

.personal-info {
  flex: 1;
  background-color: #fafafa;
}

.announcement {
  flex: 3;
  background-color: #f0f0f0;
}


.announcement-list {
}


.sidebar {
  flex: 1;
  width: 15%;
  background-color: #f0f0f0;
  padding: 15px;
}
.content {
  flex: 5;
  background-color: #ffffff;
}
.avatar {
  width: 110px;
  height: 110px;
  border-radius: 0;

}

.avatar img {
  margin-top: 10px;
  margin-left: 10px;
  width: 160%;
  height: 160%;
  object-fit: cover;
}

.user-info {
  margin-left: 90px;
  margin-bottom: 0;
  position: center;
}

.name {
  font-size: 18px;
  margin-top: 5px;
}

.department,
.employee-id {
  font-size: 18px;
  margin-top: 8px;
}
.title-bar {
  display: flex;
  justify-content: space-between;

  padding: 10px;
  background-color: #f5f5f5;
}
.title1 {
  font-size: 20px;
  font-weight: bold;
  margin-left: 15px;
}
.title2 {
  font-size: 18px;
  font-weight: bold;
  margin-left: 20px;
}

.link {
  color: #409eff;
  cursor: pointer;
  margin-right: 10px;
}

.complaintsadjust{
  margin-left: 20px;
  margin-right: 10px;
}
ul {
  list-style-type: none;
  padding: 0;
  margin-top: 0;
}

li {
  margin-bottom: 10px;
  font-size: 17px;
}

.fontsize{
  font-size: 16px;
}
.announcement-details {
  padding: 200px;
  background-color: #f5f5f5;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.announcement-title {
  font-size: 24px;
  font-weight: bold;
  margin-top: -180px;
}

.announcement-time {
  color: #888;
  margin-bottom: 20px;
}

.announcement-content {
  font-size: 16px;
  line-height: 1.5;
}
</style>
