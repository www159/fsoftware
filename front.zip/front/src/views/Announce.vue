<template>
  <div class="announce-management">
    <!-- 标题栏 -->
    <div class="title-bar">
      <div class="title">公告信息管理</div>
      <div class="link" @click="openAnnounceDialog">新增公告</div>
    </div>
    <!-- 搜索栏 -->
    <el-row class="search-row">
      <el-col :span="7">
        <el-input v-model="search.title" placeholder="请输入标题"></el-input>
      </el-col>
      <el-col :span="5">
        <el-date-picker v-model="search.time" type="date" placeholder="选择日期"></el-date-picker>
      </el-col>
      <el-col :span="1">
        <el-button type="primary" @click="searchAnnouncements">搜索</el-button>
      </el-col>
    </el-row>

    <!-- 公告信息展示表格 -->
    <el-table :data="announcements" style="width: 100%">
      <el-table-column label="公告编号" prop="infoId"></el-table-column>
      <el-table-column label="公告标题" prop="title"></el-table-column>
      <el-table-column label="日期" prop="time" :formatter="formatDate"></el-table-column>
      <el-table-column label="状态" prop="state"><template #default="{ row }">
        {{ statusMappings[row.state] }}
      </template></el-table-column>
      <el-table-column label="操作">
        <template #default="{ row }">
          <el-button type="text" @click="editAnnouncement(row)">编辑</el-button>
          <!--          <el-button type="text" @click="deleteAnnouncement(row)">停用/启用</el-button>-->
          <el-button type="text" @click="changeAnnouncement(row)">
            {{ row.state === 0? '启用' : '停用' }}
          </el-button>
          <el-button type="text" @click="deleteAnnounce(row.infoId)">删除</el-button>
        </template>
      </el-table-column>

    </el-table>
  </div>
  <el-dialog  title="新的公告" v-model="AnnouncedialogVisible">
    <!-- 投诉表单 -->
    <el-form ref="announceForm" :model="announceForm" label-width="80px">
      <el-form-item label="公告标题">
        <el-input v-model="announceForm.announceTitle"></el-input>
      </el-form-item>
      <el-form-item label="公告内容">
        <el-input v-model="announceForm.announceContent" type="textarea"></el-input>
      </el-form-item>
      <el-form-item label="公告日期">
        <el-date-picker v-model="announceForm.announceDate" type="date" placeholder="选择日期"></el-date-picker>
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="announceForm.announceMemo" type="textarea"></el-input>
      </el-form-item>
      <!-- 其他表单项根据需要添加 -->

      <!-- 提交按钮 -->
      <el-form-item>
        <el-button type="primary" @click="submitAnnounceForm">提交</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
  <el-dialog title="编辑公告" v-model="editDialogVisible">
    <el-form ref="editForm" :model="editForm" label-width="80px">
      <el-form-item label="公告标题">
        <el-input v-model="editForm.title"></el-input>
      </el-form-item>
      <el-form-item label="公告内容">
        <el-input v-model="editForm.content" type="textarea"></el-input>
      </el-form-item>
      <el-form-item label="公告日期">
        <el-date-picker v-model="editForm.time" type="date" placeholder="选择日期"></el-date-picker>
      </el-form-item>
      <el-form-item label="备注">
        <el-input v-model="editForm.memo" type="textarea"></el-input>
      </el-form-item>

      <el-form-item>
        <el-button @click="cancelEdit">取消</el-button>
        <el-button type="primary" @click="saveEdit">完成</el-button>
      </el-form-item>
    </el-form>
  </el-dialog>
</template>

<script>

import ServicePort from './ServicePort';
import axios from "axios";
export default {
  name:'announce',
  data() {
    return {

      // currentPage: 1, //默认页码为1
      // pagesize: 5, //默认一页显示10条
      // searchTitle: '',
      // searchDate: '',
      search: {
        title: '',
        time: '',
      },
      statusMappings: {
        '0': '停用',
        '1': '启用',
      },
      editDialogVisible: false,
      editForm: {
        title: '',
        content: '',
        time: '',
        memo: '',
      },
      // 当前正在编辑的公告
      currentEditAnnouncement: null,
      announcements: [],
      announceForm: { // 投诉表单数据
        announceTitle: '',
        announceContent: '',
        announceDate:'',
        announceMemo:'',
        // 其他表单字段根据需要添加
      },
      AnnouncedialogVisible: false,
    };
  },
  mounted() {
    this.fetchAnnounce();
  },
  methods: {
    editAnnouncement(row) {
      // 将当前编辑的公告保存到数据中
      this.currentEditAnnouncement = row;

      // 将公告信息填充到编辑表单中
      this.editForm.title = row.title;
      this.editForm.content = row.content;
      this.editForm.time = row.time;
      this.editForm.memo = row.memo;

      // 打开编辑对话框
      this.editDialogVisible = true;
    },
    cancelEdit() {
      // 清空编辑表单
      this.editForm.title = '';
      this.editForm.content = '';
      this.editForm.time = '';
      this.editForm.memo = '';

      // 关闭编辑对话框
      this.editDialogVisible = false;
    },
    async saveEdit() {
      try {
        const announceData = {
          title: this.editForm.title,
          content: this.editForm.content,
          time: this.editForm.time,
          memo: this.editForm.memo,
        };

        // 发送请求更新公告信息
        await axios.put(`http://localhost:80/info/${this.currentEditAnnouncement.infoId}`, announceData);

        // 清空编辑表单
        this.editForm.title = '';
        this.editForm.content = '';
        this.editForm.time = '';
        this.editForm.memo = '';
        alert('编辑公告成功');
        // 关闭编辑对话框
        this.editDialogVisible = false;

        // 重新获取公告列表
        this.fetchAnnounce();
      } catch (error) {
        // 处理错误
      }
    },
    formatDate(row, column) {
      const date = new Date(row.time);
      const year = date.getFullYear();
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const day = date.getDate().toString().padStart(2, '0');
      return `${year}-${month}-${day}`;
    },
    async deleteAnnounce(infoId) {
      try {
        const success = await ServicePort.deleteAnnounce(infoId);
        await this.fetchAnnounce();
      } catch (error) {
        // 处理错误
      }
    },
    async changeAnnouncement(row) {
      try {
        const infoId = row.infoId;
        const newState = row.state === 0 ? 1 : 0;
        console.log(infoId,newState);
        const response = await axios.put(`http://localhost:80/info/${infoId}`, { state: newState });

        if (response.status === 200) {
          alert('修改公告状态成功');
          // Update the state locally
          await this.fetchAnnounce();
        } else {
          // Handle the response error
        }
      } catch (error) {
        // Handle the error
      }
    },
    async fetchAnnounce() {
      try {
        const searchParams = {
          title: this.search.title,
          time: this.search.time,
        };
        const announcements = await ServicePort.fetchAnnounce(searchParams);
        this.announcements = announcements;
      } catch (error) {
        // 处理错误
      }
    },

    async submitAnnounceForm() {
      try {
        const announceData = {
          title: this.announceForm.announceTitle,
          content: this.announceForm.announceContent,
          time: this.announceForm.announceDate,
          memo: this.announceForm.announceMemo,
        };
        await ServicePort.addAnnounce(announceData);
        this.announceForm = {
          announceTitle: '',
          announceContent: '',
          announceDate: '',
          announceMemo: '',
        };
        alert('新增公告成功')
        this.AnnouncedialogVisible = false;
        await this.fetchAnnounce();
      } catch (error) {
        // 处理错误
      }
    },
    //删除公告
    // async deleteAnnounce (infoId) {
    //   await axios.delete(`http://localhost:80/info/${infoId}`,).then((response)=>
    //       {
    //         if(response.status===200){
    //           alert('删除成功')
    //           this.fetchAnnounce ();
    //         }
    //         else(
    //             alert('删除失败')
    //         )
    //       }
    //   )
    // },
    // //展示公告
    // async fetchAnnounce() {
    //   console.log(this.search.title,this.search.time)
    //   await axios.get('http://localhost:80/info/list', {
    //     params:{
    //       title:this.search.title ,
    //       time:this.search.date,
    //     }})
    //       .then(response => {
    //         this.announcements = response.data;
    //
    //       })
    //       .catch(error => {
    //         console.error('获取公告信息时出错:', error);
    //       });
    // },
    searchAnnouncements() {
      // 根据搜索条件执行搜索逻辑
      this.fetchAnnounce();
    },

    openAnnounceDialog() {
      this.AnnouncedialogVisible = true;
    },

    // async submitAnnounceForm() {
    //   const postData = {
    //     title: this.announceForm.announceTitle,
    //     content: this.announceForm.announceContent,
    //     time: this.announceForm.announceDate,
    //     memo: this.announceForm.announceMemo
    //   };
    //  await axios.post('http://localhost:80/info', postData)
    //
    //       .then(response => {
    //         // 处理成功响应
    //         console.log('添加公告成功');
    //         // 清空表单数据
    //         this.announceForm = {
    //           announceTitle: '',
    //           announceContent: '',
    //           announceDate: '',
    //           announceMemo: '',
    //         };
    //         // 关闭对话框
    //         this.AnnouncedialogVisible = false;
    //         // 刷新公告列表
    //         this.fetchAnnounce();
    //       })
    //       .catch(error => {
    //         // 处理错误响应
    //         console.error('添加公告失败:', error);
    //       });
    //   // this.$refs.announceForm.resetFields();
    // },

  }

};

</script>

<style scoped>
.announce-management {
  padding: 0;
}

.title {
  color: #000;
  font-size: 24px;
}

.search-row {
  margin-top: 10px;
  margin-bottom: 10px;
}
.title-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #f5f5f5;
}
</style>
