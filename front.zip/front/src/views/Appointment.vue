<template>
  <div class="appointment-management">
    <!-- 标题栏 -->
    <div class="title-bar">
      <div class="title">预约信息受理</div>
      <div class="link" @click="outerVisible = true">可预约事项管理</div>
    </div>
    <!-- 搜索栏 -->
    <el-row class="search-row">
      <el-col :span="7">
        <el-input v-model="search.title" placeholder="请输入预约事项名称"></el-input>
      </el-col>
      <el-col :span="7">
        <el-date-picker v-model="search.time" type="datetimerange" placeholder="选择日期"></el-date-picker>
      </el-col>

      <el-col :span="4" >
        <el-form-item>
          <el-select v-model.trim="search.state" clearable placeholder="状态" >
            <el-option
                v-for="item in AcceptedOrNot"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>
      </el-col>
      <el-col :span="1">
        <el-button type="primary" @click="searchAppointmentments">搜索</el-button>
      </el-col>
    </el-row>

    <!-- 公告信息展示表格 -->

    <el-table :data="appointments" style="width: 100%">
      <el-table-column label="预约编号" prop="reservationId"></el-table-column>
      <el-table-column label="预约事项" prop="name"></el-table-column>
      <el-table-column label="预约人姓名" prop="reserveName"></el-table-column>
      <el-table-column label="预约时间" prop="reservationTime"></el-table-column>
      <el-table-column label="状态" prop="state">
        <template #default="{ row }">
          {{ statusMappings[row.state] }}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template #default="{ row }">
          <el-button type="text" @click="changeAnnouncement(row)">处理</el-button>
        </template>
      </el-table-column>
    </el-table>

  </div>
  <el-dialog v-model="outerVisible" title="可预约事项" :width="`${outerWidth}px`">

    <template #default>
      <el-dialog
          v-model="innerVisible"
          :width="`${innerWidth}px`"
          title="新增可预约事项"
          append-to-body
      >
        <el-form ref="matterForm" :model="matterForm" label-width="150px">
          <el-form-item label="预约事项名称">
            <el-input v-model="matterForm.matterName"></el-input>
          </el-form-item>
          <el-form-item label="预约事项处理部门">
            <el-input v-model="matterForm.matterDept"></el-input>
            <!-- 其他表单项根据需要添加 -->
            <!-- 提交按钮 -->
            <el-form-item>
              <div class="tijiao">
                <el-button type="primary" @click="submitMatterForm">提交</el-button></div>
            </el-form-item>
          </el-form-item>
        </el-form>
      </el-dialog>
    </template>
    <template #footer>
      <div class="matteradjust">
        <el-row class="search-row">
          <el-col :span="7">
            <el-input v-model="search.MatterTitle" placeholder="请输入事项名称"></el-input>
          </el-col>
          <el-col :span="7">
            <el-input v-model="search.MatterDept" placeholder="请输入处理部门"></el-input>
          </el-col>
          <el-col :span="2">
            <el-button type="primary" @click="searchMatters">搜索</el-button>
          </el-col>
        </el-row>
        <el-table :data="matters" style="width: 900px">
          <el-table-column label="事项编号" prop="reservationItemId" width="230px"></el-table-column>
          <el-table-column label="事项名称" prop="name" width="230px"></el-table-column>
          <el-table-column label="处理部门" prop="department" width="230px"></el-table-column>
          <el-table-column label="操作" width="210px">
            <template #default="{ row }">
              <el-button type="text" @click="changeMatter(row)">修改</el-button>
              <el-button type="text" @click="deleteMatters(row.reservationItemId)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="dialog-footer">
        <el-button @click="outerVisible = false">关闭</el-button>
        <el-button type="primary" @click="innerVisible = true">
          新增可预约事项
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script>

import {ElDialog} from "element-plus";
import ServicePort from './ServicePort';
import axios from "axios";
export default {
  name:'appointment',
  data() {
    return {
      statusMappings: {
        '0': '未处理',
        '1': '预约成功',
        '2': '预约失败',
      },
      outerWidth: 1000,
      innerWidth: 800,
      outerVisible: false,
      innerVisible: false,
      searchTitle: '',
      searchDate: '',
      searchMatterTitle:'',
      searchMatterDept:'',
      search:{
        title:'',
        time:'',
        state:'',
        MatterTitle:'',
        MatterDept:'',
      },
      appointments: [

      ],
      matters: [],
      appointmentForm: { //
        appointmentNumber: '',
        appointmentTitle: '',
        appointmentContent: '',
        appointmentDate:'',
        isAccepted:'',
        // 其他表单字段根据需要添加
      },
      matterForm: { //
        matterName: '',
        matterDept: '',
        // 其他表单字段根据需要添加
      },
      AcceptedOrNot:[
        {
          value: '1',
          label: '预约成功',
        },
        {
          value: '2',
          label: '预约失败',
        },
        {
          value: '0',
          label: '未处理',
        },
      ],
      appointmentdialogVisible: false,

    };
  },
  mounted() {
    this.fetchMatter();
    this.fetchAppointment();
  },
  methods: {
    async fetchAppointment() {
      try {
        const searchParams = {
          reservationItemName: this.search.title,
          startDate: this.search.time[0], // 开始日期
          endDate: this.search.time[1],   // 结束日期
          state: this.search.state,
        };
        const appointments = await ServicePort.fetchAppointments(searchParams);
        this.appointments = appointments;
      } catch (error) {
        // 处理错误
      }
    },
    //展示可预约事项
    async fetchMatter() {
      try {
        const searchParams = {
          name: this.search.MatterTitle,
          department: this.search.MatterDept,
        };
        const matters = await ServicePort.fetchMatter(searchParams);
        this.matters = matters;
      } catch (error) {
        // 处理错误
      }
    },
    searchMatters() {
      this.fetchMatter();
    },
    async deleteMatter(reservationItemId) {
      try {
        await ServicePort.deleteMatter(reservationItemId);
        this.fetchMatter();
      } catch (error) {
        // 处理错误
      }
    },
    searchAppointmentments() {
      this.fetchAppointment();
    },
    async changeAnnouncement(row) {
      try {
        const reservationId = row.reservationId;
        const newState = {
          state: row.state === 0 ? 1 : 0,
          reservationItemId:row.reservationItemId,
          submitterId: row.submitterId
        }
        console.log(reservationId,newState);
        const response = await axios.put(`http://localhost:80/Reservation/update/${reservationId}`, newState);

        if (response.status === 200) {
          alert('修改预约状态成功');
          // Update the state locally
          this.fetchAppointment();
        } else {
          // Handle the response error
        }
      } catch (error) {
        // Handle the error
      }
    },
    changeMatter(announcement) {
      // 查看指定的操作逻辑
    },
    deleteMatters(reservationItemId) {
      this.deleteMatter(reservationItemId);
      // 删除指定的操作逻辑
    },
    async submitMatterForm() {
      try {
        const matterData = {
          name: this.matterForm.matterName,
          department: this.matterForm.matterDept,
        };
        await ServicePort.addMatter(matterData);
        this.matterForm = {
          matterName: '',
          matterDept: '',
        };
        alert('新增可预约事项成功')
        this.innerVisible = false;
        this.fetchMatter();
      } catch (error) {
        // 处理错误
      }
    },
  }
};
</script>

<style scoped>
.appointment-management {
  padding: 0;
}

.title {
  color: #000;
  font-size: 24px;
}

.search-row {
  margin-top: 10px;
  margin-bottom: 10px;
}
.title-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #f5f5f5;
}
.matteradjust{
  margin-top: -40px;
}
.tijiao{
  margin-top: 10px;
}
.dialog-footer{
  margin-top: 10px;
}
</style>
