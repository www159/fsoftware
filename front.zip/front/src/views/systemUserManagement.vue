<template>
  <div>
    <el-card>
      <el-row :gutter="20">
        <el-col :span="8">
          <!-- 搜索与添加区域 -->
          <el-input placeholder="请输入内容" v-model.trim.lazy="searchText" @keyup.enter="searchTableData">
            <template #append>
              <el-button class="el-icon-search" @click="searchTableData"></el-button>
            </template>
          </el-input>
        </el-col>
        <el-col :span="4">
          <el-button type="primary" @click="openAddUserDialog">添加用户</el-button>
        </el-col>
        <!--        <el-col :span="4">-->
        <!--          <el-button type="danger" @click="multipleDelete">批量删除</el-button>-->
        <!--        </el-col>-->
        <!--        <el-col :span="4">-->
        <!--          <el-button type="info" @click="selectAllRows">全选</el-button>-->
        <!--        </el-col>-->
      </el-row>
    </el-card>
    <el-scrollbar style="width: 100%;">
      <el-table :data="paginatedTableData" ref="multipleTableRef" @selection-change="handleSelectionChange"
                style="overflow-x: auto;">
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="name" label="用户名称" width="200"></el-table-column>
        <el-table-column prop="password" label="密码" width="200"></el-table-column>
        <el-table-column prop="dept" label="部门" width="200"></el-table-column>
        <el-table-column prop="company" label="公司" width="200"></el-table-column>
        <el-table-column prop="gender" label="性别" width="200">
          <template #default="scope">
            <span>{{ scope.row.gender === 0 ? '女生' : '男生' }}</span>
          </template>
        </el-table-column>
        <el-table-column label="状态" prop="state" width="200">
          <template #default="scope">
            <span>{{ scope.row.state === 0 ? '禁用' : '正常' }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="mobile" label="手机号码" width="200"></el-table-column>
        <el-table-column prop="email" label="邮箱" width="200"></el-table-column>
        <el-table-column prop="birthday" label="生日" width="200"></el-table-column>
        <el-table-column prop="account" label="工号" width="200"></el-table-column>
        <el-table-column prop="headImg" label="图像url" width="200"></el-table-column>
        <el-table-column prop="memo" label="备注" width="200"></el-table-column>
        <el-table-column prop="role" label="用户角色" width="200"></el-table-column>

        <!--        <el-table-column prop="status" label="状态"></el-table-column>-->
        <el-table-column label="操作" width="200">
          <template v-slot="scope">
            <el-button type="primary" @click="editUser(scope.row)">编辑</el-button>
            <el-button type="danger" @click="deleteUser(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-scrollbar>

    <!-- 添加/编辑用户弹窗 -->
    <el-dialog v-model="showAddUserDialog" title="添加用户" @close="resetEditingRole">
      <el-form :model="editingUser" label-width="100px" :rules="formRules" ref="addRoleForm">
        <el-form-item label="用户名称" prop="name">
          <el-input v-model="editingUser.name" :disabled="editingUser.editing"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="editingUser.password" type="password"></el-input>
        </el-form-item>
        <el-form-item label="部门" prop="dept">
          <el-input v-model="editingUser.dept"></el-input>
        </el-form-item>
        <el-form-item label="公司" prop="company">
          <el-input v-model="editingUser.company"></el-input>
        </el-form-item>
        <el-form-item label="性别" prop="gender">
          <el-select v-model="editingUser.gender">
            <el-option label="男" :value="true"></el-option>
            <el-option label="女" :value="false"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="用户状态" prop="state">
          <el-select v-model="editingUser.state">
            <el-option label="正常" :value="1"></el-option>
            <el-option label="禁用" :value="0"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="手机号码" prop="mobile">
          <el-input v-model="editingUser.mobile"></el-input>
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="editingUser.email"></el-input>
        </el-form-item>
        <el-form-item label="生日" prop="birthday">
          <el-date-picker v-model="editingUser.birthday" type="date" placeholder="选择日期"></el-date-picker>
        </el-form-item>
        <el-form-item label="工号" prop="account">
          <el-input v-model="editingUser.account"></el-input>
        </el-form-item>
        <el-form-item label="图像url" prop="headImg">
          <el-input v-model="editingUser.headImg"></el-input>
        </el-form-item>
        <el-form-item label="备注" prop="memo">
          <el-input v-model="editingUser.memo"></el-input>
        </el-form-item>
        <el-form-item label="用户角色" prop="role">
          <el-select v-model="editingUser.role">
            <el-option label="个人空间与纳税服务" :value="1"></el-option>
            <el-option label="个人空间" :value="2"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="cancelAddUser">取消</el-button>
        <el-button type="primary" @click="saveUser">保存</el-button>
      </div>
    </el-dialog>


    <!--分页-->
    <el-pagination
        @size-change="handlePageSizeChange"
        @current-change="handleCurrentPageChange"
        :current-page="currentPage"
        :page-sizes="[10, 20, 30, 50]"
        :page-size="pageSize"
        :total="filteredTableData.length"
        layout="sizes, prev, pager, next, jumper"
        class="pagination-centered"
    >
    </el-pagination>
  </div>
</template>

<script>
import {ref, computed, watch, onMounted} from 'vue';
import axios from 'axios';
import ServicePort from './ServicePort';
import {
  ElTable,
  ElDialog,
  ElMessageBox,
  ElForm,
  ElFormItem,
  ElInput,
  ElButton,
  ElMessage,
  ElPagination
} from 'element-plus';

export default {
  components: {ElTable, ElDialog, ElMessageBox, ElForm, ElFormItem, ElInput, ElButton, ElMessage, ElPagination},
  setup() {
    const port = 80;
    const searchText = ref('');
    const tableData = ref([]);
    //搜索数据
    const filteredTableData = ref([]);
    //tableData副本
    const allTableData = ref([]);
    const showAddUserDialog = ref(false);
    const editingUser = ref({});
    const multipleTableRef = ref();
    const multipleSelection = ref([]);
    // 分页
    const currentPage = ref(1);
    const pageSize = ref(5);
    const totalPages = ref(0);
    //弹窗
    const formRules = {
      name: [
        {required: true, message: '用户名称不能为空', trigger: 'blur'},
      ],
      password: [
        {required: true, message: '密码不能为空', trigger: 'blur'},
      ],
      dept: [
        {required: true, message: '部门不能为空', trigger: 'blur'},
      ],
      company: [
        {required: true, message: '公司不能为空', trigger: 'blur'},
      ],
      gender: [
        {required: true, message: '性别不能为空', trigger: 'blur'},
      ],
      state: [
        {required: true, message: '用户状态不能为空', trigger: 'blur'},
      ],
      mobile: [
        {required: true, message: '手机号码不能为空', trigger: 'blur'},
      ],
      email: [
        {required: true, message: '邮箱不能为空', trigger: 'blur'},
      ],
      birthday: [
        {required: true, message: '生日不能为空', trigger: 'change'},
      ],
      account: [
        {required: true, message: '账户信息不能为空', trigger: 'blur'},
      ],
      role: [
        {required: true, message: '用户角色不能为空', trigger: 'blur'},
      ],
    };
    // const filteredTableData = computed(() => {
    //   if (searchText.value) {
    //     const keyword = searchText.value.trim().toLowerCase();
    //     return tableData.value.filter((item) => item.name.toLowerCase().includes(keyword));
    //   } else {
    //     return tableData.value;
    //   }
    // });
    // const isDataLoaded = ref(false);
    //获取数据
    const fetchTableData = async () => {
      try {
        const userData = await ServicePort.fetchUser();
        //test
        // // console.log("tableData:",data);
        // isDataLoaded.value = true;
        console.log(userData);
        for (let i = 0; i < userData.length; i++) {
          const userId = userData[i].id;
          console.log(userId);
          const userRoleResponse = await axios.get(`http://localhost:${port}/users/getRoleId/${userId}`);
          console.log(userRoleResponse.data)
          if (userRoleResponse) {
            userData[i].role = userRoleResponse.data; // 将user_role的role列数据添加到user表中的对应行数据对象的role属性
          }
        }
        console.log(userData);

        tableData.value = userData;
        allTableData.value = [...data];
        filteredTableData.value = tableData;
        //test
        // console.log("filteredTableData:",filteredTableData);
        // console.log("tableData:",tableData);
      } catch (error) {

      }
    };

    onMounted(() => {
      fetchTableData();
    });

    const searchTableData = () => {
      // 清除当前页和选择的数据
      currentPage.value = 1;
      multipleSelection.value = [];

      if (searchText.value) {
        const keyword = searchText.value.trim().toLowerCase();
        const filteredData = tableData.value.filter((item) => item.name.toLowerCase().includes(keyword));
        if (filteredData.length === 0) {
          ElMessageBox.alert('查询失败', '提示', {
            type: 'error',
          });
        } else {
          filteredTableData.value = filteredData;
          totalPages.value = Math.ceil(filteredData.length / pageSize.value);
        }
      } else {
        filteredTableData.value = tableData.value;
      }
    };

    // const multipleDelete = () => {
    //   if (multipleSelection.value.length > 0) {
    //     ElMessageBox.confirm('确定要删除选中的数据吗？', '提示', {
    //       type: 'warning',
    //     })
    //         .then(() => {
    //           const selectedRows = multipleSelection.value;
    //           tableData.value = tableData.value.filter((row) => !selectedRows.includes(row));
    //           multipleSelection.value = [];
    //           ElMessage.success('删除成功');
    //         })
    //         .catch(() => {
    //           // 取消删除
    //         });
    //   } else {
    //     ElMessage.warning('请先选择要删除的数据');
    //   }
    // };

    // const multipleDelete = async () => {
    //   if (multipleSelection.value.length > 0) {
    //     try {
    //       const selectedRows = multipleSelection.value;
    //       const roleIds = selectedRows.map((row) => row.roleId); // 唯一的 id 字段
    //       console.log(roleIds);
    //       await axios.delete(`http://localhost:${port}/roles/batch`, {data: roleIds});
    //       tableData.value = tableData.value.filter((row) => !selectedRows.includes(row)); // 在前端中过滤掉选中的行数据
    //       multipleSelection.value = [];
    //       ElMessage.success("批量删除成功");
    //     } catch (error) {
    //       console.error("Error deleting roles:", error);
    //     }
    //   } else {
    //     ElMessage.warning("请先选择要删除的数据");
    //   }
    // };

    // const selectAllRows = () => {
    //   if (isAllSelected) {
    //     // 已经全选，取消全选
    //     multipleSelection.value = [];
    //   } else {
    //     // 未全选，全选所有数据行
    //     console.log(filteredTableData)
    //     multipleSelection.value = [...filteredTableData.value];
    //   }
    // };
    //
    // const isAllSelected = computed(() => multipleSelection.value.length === filteredTableData.value.length);


    const editUser = (row) => {
      showAddUserDialog.value = true;
      editingUser.value = {...row, editing: true, operation: 'editUserOperation'};
    };

    // const deleteUser = (index) => {
    //   console.log(tableData.value[index])
    //   console.log(tableData.value[index].roleId)
    //   tableData.value.splice(index, 1);
    // };

    const deleteUser = async (row) => {
      console.log(row)
      const userId = row.id; // 唯一的 id 字段
      console.log(userId);
      console.log(row);
      try {
        await axios.delete(`http://localhost:${port}/users/delete/${userId}`);
        tableData.value = tableData.value.filter((item) => item.id !== userId);// 在前端中删除指定索引位置的数据
        filteredTableData.value = filteredTableData.value.filter((item) => item.id !== userId); // 更新 filteredTableData
      } catch (error) {
        console.error("Error deleting role:", error);
      }
    };


    const openAddUserDialog = () => {
      showAddUserDialog.value = true;
      editingUser.value = {editing: false, operation: 'addUserOperation'};
    };

    const cancelAddUser = () => {
      showAddUserDialog.value = false;
      editingUser.value = {};
    };

    const saveUser = async () => {
      if (editingUser.value.name &&
          editingUser.value.account &&
          editingUser.value.birthday &&
          editingUser.value.company &&
          editingUser.value.dept &&
          editingUser.value.email &&
          editingUser.value.mobile &&
          editingUser.value.password) {

        if (editingUser.value.editing) {
          //编辑
          // console.log(editingUser.value);
          // console.log(editingUser.value.roleId);
          // console.log(editingUser.value.roleId);
          // console.log(updateRole);
          const updateUser = {...editingUser.value};
          // console.log(editingUser.value);
          delete updateUser.operation;
          delete updateUser.editing;
          // const updateUserSSS = {...updateUser};
          // console.log("updateUserSSS.role", updateUserSSS.role);
          delete updateUser.role;
          // console.log(updateUser);  //打印更新后的User行数据
          const response = await axios.put(`http://localhost:${port}/users/update/${updateUser.id}`, {data: updateUser});
          console.log(response); // 可选：打印响应结果
          const index = tableData.value.findIndex((role) => role.name === editingUser.value.name);
          if (index !== -1) {
            tableData.value[index] = {...editingUser.value, editing: false};
          }
        } else {
          const existingUser = tableData.value.find((user) => user.name === editingUser.value.name);
          if (existingUser) {
            ElMessage.warning('该用户已存在');
            return; // 如果存在相同的用户，停止保存操作
          }
          //保存
          // console.log("editingUser", editingUser.value);
          // console.log("editing.value.role", editingUser.value.role);
          const addRole = {
            userId: tableData.value.length + 1,
            roleId: editingUser.value.role
          };
          // console.log("addRole", addRole);
          await axios.post(`http://localhost:${port}/users/setUserRole?roleId=${addRole.roleId}&userId=${addRole.userId}`);
          const addUser = {
            ...editingUser.value,
            id: tableData.value.length + 1,
            admin: 0
          };
          delete addUser.operation;
          delete addUser.editing;
          delete addUser.role;
          // console.log(editingUser.value);
          // console.log(addUser);
          const response = await axios.post(`http://localhost:${port}/users/addUser`, addUser);
          console.log(response);
          tableData.value.push({...editingUser.value});
        }
        showAddUserDialog.value = false;
        editingUser.value = {};
      } else {
        ElMessage.warning('请填写必要信息');
      }
    };

    const resetEditingRole = () => {
      editingUser.value = {};
    };

    const handleSelectionChange = (val) => {
      multipleSelection.value = val;
    };

    const paginatedTableData = computed(() => {
      const startIndex = (currentPage.value - 1) * pageSize.value;
      const endIndex = startIndex + pageSize.value;
      totalPages.value = Math.ceil(filteredTableData.value.length / pageSize.value);
      return filteredTableData.value.slice(startIndex, endIndex);
    });

    const handlePageSizeChange = (newPageSize) => {
      pageSize.value = newPageSize;
      currentPage.value = 1;
    };

    const handleCurrentPageChange = (newPage) => {
      const totalPages = Math.ceil(filteredTableData.value.length / pageSize.value);
      currentPage.value = Math.max(1, Math.min(newPage, totalPages));
    };

    watch(tableData, (newTableData) => {
      filteredTableData.value = newTableData;
    });

    return {
      searchText,
      tableData,
      showAddUserDialog,
      editingUser,
      multipleTableRef,
      multipleSelection,
      currentPage,
      pageSize,
      totalPages,
      filteredTableData,
      formRules,
      searchTableData,
      // multipleDelete,
      // selectAllRows,
      editUser,
      deleteUser,
      openAddUserDialog,
      cancelAddUser,
      saveUser,
      resetEditingRole,
      handleSelectionChange,
      paginatedTableData,
      handlePageSizeChange,
      handleCurrentPageChange,
    };


  },
};
</script>
