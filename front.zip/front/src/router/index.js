import { createRouter, createWebHistory } from 'vue-router'
import LoginView from "@/views/LoginView.vue";
import Myworkspace from '../views/MyworkspaceView.vue'
import TaxService from "@/views/TaxService.vue";
import Announce from "@/views/Announce.vue";
import Appointment from "@/views/Appointment.vue";
import Complaint from "@/views/Complaint.vue";
import Consult from "@/views/Consult.vue";
import Einform from "@/views/Einform.vue";
import Questionnaire from "@/views/Questionnaire.vue";
import Test from "@/views/QuestionnaireTest.vue";

const routes = [
  {
    path: '/myworkspace',
    name: 'myworkspace',
    component: Myworkspace,
    meta: { title: '个人工作台' }
  },
  {
    path: '/czxtest',
    name: 'czxtest',
    component: Test,
    meta: { title: 'test' }
  },
  {
    path: '/taxservice',
    name: 'taxservice',
    component: TaxService,
    meta: { title: '纳税服务' },
    children: [
      { 	path: 'announce',
        component: Announce ,
        meta: {
          title: '公告信息管理'
        }
      },
      { 	path: 'complaint',
        component: Complaint ,
        meta: {
          title: '投诉受理'
        }
      },
      {
        path: 'consult',
        component: Consult,
        meta: {
          title: '纳税咨询'
        }
      },
      { 	path: 'einform',
        component: Einform ,
        meta: {
          title: '易告知'
        }
      },
      { 	path: 'appointment',
        component: Appointment ,
        meta: {
          title: '服务预约'
        }
      },
      { 	path: 'questionnaire',
        component: Questionnaire ,
        meta: {
          title: '服务调查'
        }
      }
    ]
  },
  {
    path: '/adminHomePage',
    name: 'adminHomePage',
    component: () => import('../views/adminHomePage.vue'  ),
    redirect: '/actorManagement',
    //二级路由
    children:[
      {
        //角色管理
        path: '/actorManagement',
        name: 'actorManagement',
        component:  () => import('@/views/actorManagement.vue')
      },
      {
        //用户管理
        path:'/systemUserManagement',
        name:'systemUserManagement',
        component: ()=>import('@/views/systemUserManagement.vue'  )
      }
    ]
  },
  {
    path: '/',
    name: 'login',
    component: LoginView
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
