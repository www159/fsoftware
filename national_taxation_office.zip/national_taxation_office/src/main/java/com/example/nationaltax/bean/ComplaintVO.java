package com.example.nationaltax.bean;

public class ComplaintVO {
    //@todo 等前端
}
