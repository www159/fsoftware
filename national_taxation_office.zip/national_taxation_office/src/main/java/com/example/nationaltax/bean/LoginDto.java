package com.example.nationaltax.bean;

import lombok.Data;

@Data
public class LoginDto {
    private String account;
    private String password;
}
