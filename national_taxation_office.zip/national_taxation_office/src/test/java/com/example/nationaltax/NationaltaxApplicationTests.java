package com.example.nationaltax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NationaltaxApplicationTests {

    @Test
    void contextLoads() {
    }

}
